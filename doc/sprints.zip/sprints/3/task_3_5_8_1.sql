delete from mart.d_calendar;

insert into mart.d_calendar (
  select
	distinct to_char(date_id,'YYYYMMDD')::INTEGER as date_id, date_id::DATE as fact_date
	       , EXTRACT(isodow from date_id) as day_num
	       , extract(month from date_id) as month_num
	       , to_char(date_id, 'Mon') as month_name
	       , extract(year from date_id) as year_num
from
	(
	select
		distinct date_id
	from
		stage.customer_research
union all
	select
		distinct date_time
	from
		stage.user_activity_log
union all
	select
		distinct date_time
	from
		stage.user_order_log) as s
order by
	1 asc);

delete from mart.d_customer;
insert into mart.d_customer (
select customer_id, first_name, last_name, max(city_id) as city_id from stage.user_order_log
 group by customer_id, first_name, last_name order by 1);
	
delete from mart.d_item;
insert into mart.d_item (select distinct item_id, item_name from stage.user_order_log order by 1);


customer_id - уникальный айди пользователя из user_order_log;
city_id - максимальный идентификатор города из всех присутсвующих по пользователю в user_order_log.

CREATE TABLE mart.d_customer (
	customer_id int4 NOT NULL,
	first_name varchar(15) NULL,
	last_name varchar(15) NULL,
	city_id int4 NULL,
	CONSTRAINT d_customer_pkey PRIMARY KEY (customer_id)
);



