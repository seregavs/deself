import psycopg2
import pandas as pd
# import numpy as np
from sqlalchemy import create_engine

filelist = ['customer_research', 'user_activity_log','user_activity_log']
engine = create_engine('postgresql://jovyan:jovyan@127.0.0.1:5432/de')

ds = pd.read_csv("./stage/{0}.csv".format('user_order_log'))
ds.drop(['id2','uniq_id'], axis='columns',inplace=True)
print('Rows for {0} inserted: '.format('user_order_log'), ds.to_sql('user_order_log', engine, 'stage',if_exists='append', index=False
    , index_label=['id','date_time','city_id','city_name','customer_id','first_name','last_name','item_id','item_name','quantity','payment_amount']))

ds = pd.read_csv("./stage/{0}.csv".format('user_activity_log'))
ds.drop(['id2','uniq_id'], axis='columns',inplace=True)
print('Rows for {0} inserted: '.format('user_activity_log'), ds.to_sql('user_activity_log', engine, 'stage',if_exists='append', index=False
    , index_label=['id','date_time','action_id','customer_id','quantity']))

ds = pd.read_csv("./stage/{0}.csv".format('customer_research'))
print('Rows for {0} inserted: '.format('customer_research'), ds.to_sql('customer_research', engine, 'stage', if_exists='append', index=False
    , index_label=['id','date_id','category_id','geo_id','sales_qty','sales_amt']))

"""

delete from stage.customer_research;
delete from stage.user_activity_log;
delete from stage.user_order_log;
commit;

insert_uol = "insert into stage.user_order_log (date_time, city_id, city_name, customer_id, first_name, last_name, item_id, item_name, quantity, payment_amount) VALUES {uol_val};"
step = int(user_orders_log.shape[0] / 100)
while i <= user_orders_log.shape[0]:
    print(i, end='\r')
    s_val =  str([tuple(x) for x in user_orders_log.loc[i:i + step].to_numpy()])[1:-1]
    cur.execute(insert_s.replace('{s_val}',s_val))
    conn.commit()
    i += step+1
"""   