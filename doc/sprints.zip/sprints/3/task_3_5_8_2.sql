/*
Заполните таблицу f_activity — витрина разных вариантов активностей пользователей сгруппированных по датам и типам действий (action_id  , date_id),
где:
· activity_id — группировка по action_id из таблицы user_activity_log;
· date_id — идентификатор даты из таблицы d_calendar в соответствии с action_id из таблицы user_activity_log.
Заполните таблицу f_daily_sales — витрина данных о продажах сгруппированных по датам, товарам и пользователям (date_id , item_id, customer_id), где:
· date_id — идентификатор даты из таблицы d_calendar в соответствии с action_id из таблицы user_activity_log;
· item_id — item_id из user_order_log;
· customer_id — customer_id из user_order_log;
· price — среднее значение payment_amount / quantity из таблицы user_order_log;
· quantity — сумма quantity из таблицы user_order_log;
· payment_amount — сумма payment_amount из таблицы user_order_log.

CREATE TABLE mart.f_activity (
	activity_id int4 NOT NULL,
	date_id int4 NOT NULL,
	click_number int4 NULL,
	
CREATE TABLE mart.f_daily_sales (
	date_id int4 NOT NULL,
	item_id int4 NOT NULL,
	customer_id int4 NOT NULL,
	price numeric(10, 2) NULL,
	quantity int8 NULL,
	payment_amount numeric(10, 2) NULL,
*/

delete from mart.f_activity;
insert into mart.f_activity (
select action_id as activity_id, to_char(date_time,'YYYYMMDD')::INTEGER as date_id, sum(quantity) as click_number
  from stage.user_activity_log
  group by action_id, to_char(date_time,'YYYYMMDD')::INTEGER order by 1, 2);
  
delete from mart.f_daily_sales;
insert into mart.f_daily_sales (
 select to_char(date_time,'YYYYMMDD')::INTEGER as date_id
       , item_id
       , customer_id
       , avg(payment_amount / quantity) as price
       , sum(quantity) as quantity
       , sum(payment_amount) as payment_amount
   from stage.user_order_log
  group by to_char(date_time,'YYYYMMDD')::INTEGER, item_id, customer_id);
  
 
 delete from mart.f_activity;
 delete from mart.f_daily_sales;