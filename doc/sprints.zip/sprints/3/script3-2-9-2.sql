create schema prod;

create table prod.customer_research as (
SELECT date_id, geo_id, sales_qty, sales_amt FROM stage.customer_research);

create table prod.user_activity_log as (
SELECT date_time, customer_id FROM stage.user_activity_log);

create table prod.user_order_log as (
SELECT date_time, customer_id, quantity, payment_amount FROM stage.user_order_log);