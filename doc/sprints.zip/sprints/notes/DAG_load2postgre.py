from airflow import DAG
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.hooks.base import BaseHook
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
 

import datetime
import requests
import pandas as pd
import os
import psycopg2, psycopg2.extras
 

dag = DAG(
    dag_id='552_postgresql_export_fuction',
    schedule_interval='0 0 * * *',
    start_date=datetime.datetime(2023, 5, 23),
    catchup=False,
    dagrun_timeout=datetime.timedelta(minutes=60),
    tags=['example', 'example2'],
    params={"example_key": "example_value"},
)
business_dt = {'dt':'2022-05-06'}
 

conn_args=BaseHook.get_connection('pg_connection')
 

def load_file_to_pg(*args, **kwargs):
 

    df = pd.read_csv(f"/lessons/5. Реализация ETL в Airflow/4. Extract как подключиться к хранилищу, чтобы получить файл/Задание 2/{args[0]}", index_col=0 )
 

    cols = ','.join(list(df.columns))
    insert_stmt = f"INSERT INTO stage.{args[1]} ({cols}) VALUES %s"
 

    pg_conn = psycopg2.connect(dbname='de', port=kwargs['port'], user=kwargs['login'], host=kwargs['host'], password=kwargs['password'])
    cur = pg_conn.cursor()
 

    psycopg2.extras.execute_values(cur, insert_stmt, df.values)
    pg_conn.commit()
 

    cur.close()
    pg_conn.close()
 

load_customer_research = PythonOperator(
    task_id = 'load_customer_research',
    python_callable=load_file_to_pg,
    op_args=['customer_research.csv','customer_research'],
    op_kwargs={'port': conn_args.port, 'login': conn_args.login, 'host': conn_args.host, 'password': conn_args.password},
    dag=dag
)    
 

load_user_activity_log = PythonOperator(
    task_id = 'load_user_activity_log',
    python_callable=load_file_to_pg,
    op_args=['user_activity_log.csv','user_activity_log'],
    op_kwargs={'port': conn_args.port, 'login': conn_args.login, 'host': conn_args.host, 'password': conn_args.password},
    dag=dag
)    
 

load_user_order_log = PythonOperator(
    task_id = 'load_user_order_log',
    python_callable=load_file_to_pg,
    op_args=['user_order_log.csv','user_order_log'],
    op_kwargs={'port': conn_args.port, 'login': conn_args.login, 'host': conn_args.host, 'password': conn_args.password},
    dag=dag
)    

# надо сделать в таблицах такие же колонки и запустить DAG. Тогда все норм будет! 
# INSERT INTO stage.user_order_log (id,uniq_id,date_time,city_id,city_name,customer_id,first_name,last_name,item_id,item_name,quantity,payment_amount)
# INSERT INTO stage.user_activity_log (id,uniq_id,date_time,action_id,customer_id,quantity)

load_customer_research >> load_user_order_log >> load_user_activity_log