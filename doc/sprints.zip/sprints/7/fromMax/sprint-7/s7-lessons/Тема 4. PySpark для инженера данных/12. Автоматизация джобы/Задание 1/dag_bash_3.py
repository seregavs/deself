import airflow
import os 
# импортируем модуль os, который даёт возможность работы с ОС
# указание os.environ[…] настраивает окружение

from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import date, datetime

# прописываем пути
os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['JAVA_HOME']='/usr'
os.environ['SPARK_HOME'] ='/usr/lib/spark'
os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

# задаём базовые аргументы
default_args = {
    'start_date': datetime(2022, 6, 16),
    'end_date': datetime(2022, 6, 20),
    'catchup' : True,
    'max_active_runs' : 2,
    'owner': 'airflow'
}

# вызываем DAG
dag = DAG("maxalyapyshev_bash_new_dag",
          schedule_interval='0 0 * * *',
          default_args=default_args
         )

date = '{{ ds }}'

spark_command = f'spark-submit --master yarn --deploy-mode cluster /lessons/partition.py {date} "hdfs:///user/master/data/events" "hdfs:///user/maxalyapys/data/events"'

t1 = BashOperator(
    task_id='spark_job',
    task_concurrency = 2,
    bash_command=spark_command,
    retries=3,
    dag=dag
)

t1 