import sys

from pyspark import SparkContext, SparkConf
from pyspark.sql import SQLContext
import pyspark.sql.functions as F
 
def main():
    date = sys.argv[1]
    base_input_path = sys.argv[2]
    base_output_path = sys.argv[3]
    
    print('LOG - args done')

    conf = SparkConf().setAppName(f"EventsPartitioningJob-{date}")
    sc = SparkContext(conf=conf)
    sql = SQLContext(sc)
    print('LOG - Session created')

    # Напишите директорию чтения в общем виде
    events = sql.read.json(f"{base_input_path}/date={date}")
    print('LOG - Read done')

    # Напишите директорию записи
    events.write.partitionBy('event_type') \
    .mode("overwrite") \
    .format('parquet').save(f'{base_output_path}/date={date}')
    print('LOG - Write done') 

if __name__ == "__main__":   
    print('LOG - Main started')
    main()
    print('LOG - Main ended')
