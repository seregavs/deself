import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as F


spark = SparkSession.builder \
                    .master("yarn") \
                    .appName("Learning DataFrames") \
                    .getOrCreate()
path = "hdfs:///user/master/data/events/date=2022-05-31/*.json"
events = spark.read.json(path)
print(events.filter(F.col('event.message_to').isNotNull()).count())