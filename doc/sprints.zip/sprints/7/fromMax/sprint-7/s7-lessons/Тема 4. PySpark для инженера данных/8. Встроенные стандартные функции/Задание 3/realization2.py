import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as F


spark = SparkSession.builder \
                    .master("yarn") \
                    .appName("Learning DataFrames") \
                    .getOrCreate()
path = "hdfs:///user/master/data/events/date=2022-05-25/*.json"
events = spark.read.json(path)
events.filter(F.col('event_type')=='reaction').groupBy(F.col('event.reaction_from')).count() \
    .select(F.max('count')) \
    .withColumnRenamed('max(count)', 'max_count') \
    .show()