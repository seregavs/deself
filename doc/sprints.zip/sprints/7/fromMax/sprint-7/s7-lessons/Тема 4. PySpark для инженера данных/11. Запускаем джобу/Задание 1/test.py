import sys
  
def main():
        date = sys.argv[1]
        print(date)

if __name__ == "__main__":
        main()
