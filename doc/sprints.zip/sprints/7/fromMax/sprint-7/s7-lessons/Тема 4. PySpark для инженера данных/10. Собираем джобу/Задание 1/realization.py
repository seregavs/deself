import pyspark
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
import pyspark.sql.window as Windows

spark = SparkSession.builder \
                    .master("yarn") \
                    .appName("Fill ODS") \
                    .getOrCreate()

path_from = "hdfs:///user/master/data/events/date=2022-05-31"
#для теста только 1 день b overwrite
path_to = "hdfs:///user/maxalyapys/data/events"

df0 = spark.read.json(path_from)
df1 = df0.withColumn("date", F.to_date(F.col("event.datetime")))
print("read done")

df1.write.partitionBy("date","event_type") \
         .mode("overwrite") \
         .parquet(path_to)
print("write done")

df2 = spark.read.parquet(path_to)
df2.orderBy(F.col("event.datetime").desc())\
   .show(10) 