# прописываем пути
import os
os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['JAVA_HOME']='/usr'
os.environ['SPARK_HOME'] ='/usr/lib/spark'
os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

В терминале:
export PYSPARK_PYTHON=/usr/bin/python3
export HADOOP_CONF_DIR=/etc/hadoop/conf
export YARN_CONF_DIR=/etc/hadoop/conf
export JAVA_HOME=/usr
export SPARK_HOME=/usr/lib/spark
export PYTHONPATH=/usr/local/lib/python3.8

echo $PYSPARK_PYTHON, $HADOOP_CONF_DIR, $YARN_CONF_DIR

spark-submit --master yarn --deploy-mode cluster /lessons/partition.py "2022-05-31" "hdfs:///user/master/data/events" "hdfs:///user/maxalyapys/data/events"
