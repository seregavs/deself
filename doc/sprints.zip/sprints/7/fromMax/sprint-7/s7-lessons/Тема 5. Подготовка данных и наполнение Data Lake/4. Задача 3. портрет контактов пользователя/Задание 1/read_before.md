#!chmod +x ./run_jobs.sh делам файл выполнимим
#!./run_jobs.sh