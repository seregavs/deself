import airflow
import os 
# импортируем модуль os, который даёт возможность работы с ОС
# указание os.environ[…] настраивает окружение

from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import date, datetime

# прописываем пути
os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['JAVA_HOME']='/usr'
os.environ['SPARK_HOME'] ='/usr/lib/spark'
os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

# задаём базовые аргументы
default_args = {
    'start_date': datetime(2022, 6, 16),
    'owner': 'airflow'
}

# вызываем DAG
dag = DAG("tags_dag",
          schedule_interval=None,
          default_args=default_args
         )

spark_command_7 = "/usr/lib/spark/bin/spark-submit --master yarn --deploy-mode cluster /lessons/user_interests.py 2022-05-25 7 'hdfs:///user/maxalyapys/data/events' 'hdfs:///user/maxalyapys/analytics/user_interests_d7'"
spark_command_28 = "/usr/lib/spark/bin/spark-submit --master yarn --deploy-mode cluster /lessons/user_interests.py 2022-05-25 28 'hdfs:///user/maxalyapys/data/events' 'hdfs:///user/maxalyapys/analytics/user_interests_d28'"


t1 = BashOperator(
    task_id='user_interests_d',
    task_concurrency = 2,
    bash_command=spark_command_7,
    retries=0,
    dag=dag
)
t2 = BashOperator(
    task_id='user_interests_d28',
    task_concurrency = 2,
    bash_command=spark_command_28,
    retries=0,
    dag=dag
)

t1 >> t2