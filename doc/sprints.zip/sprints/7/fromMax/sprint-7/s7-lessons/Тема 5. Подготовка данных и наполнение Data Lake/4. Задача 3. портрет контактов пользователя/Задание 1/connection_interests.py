import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from datetime import datetime, timedelta

def input_paths(base_input_path, date, depth) -> list():

    path_list = list()

    for days_ago in range(int(depth)):
        list_date = datetime.strptime(
            date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'{base_input_path}/date={list_date}'
        path_list.append(path_item)
    return path_list

def user_contacts(date, depth, spark, base_input_path):

    paths_list = input_paths(base_input_path, date, depth)

    messages = spark.read.option("basePath", base_input_path)\
                    .parquet(*paths_list)\
                    .where("event_type='message'")
    
    user_contacts_from = (
        messages
        .filter(F.col('event.message_channel_to').isNull())
        .select(F.col("event.message_from").alias("user_id"),
                F.col("event.message_to").alias("contact_id"))
        .distinct()
    )

    user_contacts_to = (
        messages
        .filter(F.col('event.message_channel_to').isNull())
        .select(F.col("event.message_to").alias("user_id"),
                F.col("event.message_from").alias("contact_id"))
        .distinct()
    )

    user_contacts = (
        user_contacts_from
            .union(user_contacts_to)
            .distinct()
    )
    return user_contacts

def direct_tags(date, depth, spark, base_input_path):

    assert depth == 7, 'Глубина не предрасчитана'

    user_contacts_df  = user_contacts(date, depth, spark, base_input_path)

    user_interests_path  = 'hdfs:///user/maxalyapys/analytics/user_interests_d7'

    contanct_interests_df = spark.read.parquet(user_interests_path)

    wl1 = Window().partitionBy(F.col("user_id"), F.col("like_tag_top_1")).orderBy()
    wl2 = Window().partitionBy(F.col("user_id"), F.col("like_tag_top_2")).orderBy()
    wl3 = Window().partitionBy(F.col("user_id"), F.col("like_tag_top_3")).orderBy()
    wd1 = Window().partitionBy(F.col("user_id"), F.col("dislike_tag_top_1")).orderBy()
    wd2 = Window().partitionBy(F.col("user_id"), F.col("dislike_tag_top_2")).orderBy()
    wd3 = Window().partitionBy(F.col("user_id"), F.col("dislike_tag_top_3")).orderBy()

    t_wl1 = Window().partitionBy(F.col("user_id")).orderBy(F.col("ltt1_cnt").desc(),F.col("like_tag_top_1").desc())
    t_wl2 = Window().partitionBy(F.col("user_id")).orderBy(F.col("ltt2_cnt").desc(),F.col("like_tag_top_2").desc())
    t_wl3 = Window().partitionBy(F.col("user_id")).orderBy(F.col("ltt3_cnt").desc(),F.col("like_tag_top_3").desc())
    t_wd1 = Window().partitionBy(F.col("user_id")).orderBy(F.col("dtt1_cnt").desc(),F.col("dislike_tag_top_1").desc())
    t_wd2 = Window().partitionBy(F.col("user_id")).orderBy(F.col("dtt2_cnt").desc(),F.col("dislike_tag_top_2").desc())
    t_wd3 = Window().partitionBy(F.col("user_id")).orderBy(F.col("dtt3_cnt").desc(),F.col("dislike_tag_top_3").desc())


    direct_tags_df = (
            user_contacts_df
            .join(contanct_interests_df, user_contacts_df["contact_id"] == contanct_interests_df["user_id"],'inner')
            .select(user_contacts_df["user_id"], 
                    contanct_interests_df["like_tag_top_1"],
                    contanct_interests_df["like_tag_top_2"],
                    contanct_interests_df["like_tag_top_3"],
                    contanct_interests_df["dislike_tag_top_1"],
                    contanct_interests_df["dislike_tag_top_2"],
                    contanct_interests_df["dislike_tag_top_3"])
            .withColumn("row_cnt", F.lit(1).cast('int'))
            .withColumn("ltt1_cnt", F.sum("row_cnt").over(wl1))
            .withColumn("ltt2_cnt", F.sum("row_cnt").over(wl2))
            .withColumn("ltt3_cnt", F.sum("row_cnt").over(wl3))
            .withColumn("dtt1_cnt", F.sum("row_cnt").over(wd1))
            .withColumn("dtt2_cnt", F.sum("row_cnt").over(wd2))
            .withColumn("dtt3_cnt", F.sum("row_cnt").over(wd3))
            .withColumn("direct_like_tag_top_1", F.first("like_tag_top_1").over(t_wl1))
            .withColumn("direct_like_tag_top_2", F.first("like_tag_top_2").over(t_wl2))
            .withColumn("direct_like_tag_top_3", F.first("like_tag_top_3").over(t_wl3))
            .withColumn("direct_dislike_tag_top_1", F.first("dislike_tag_top_1").over(t_wd1))
            .withColumn("direct_dislike_tag_top_2", F.first("dislike_tag_top_2").over(t_wd2))
            .withColumn("direct_dislike_tag_top_3", F.first("dislike_tag_top_3").over(t_wd3))
            .select(F.col("user_id"), 
                    F.col("direct_like_tag_top_1"),
                    F.col("direct_like_tag_top_2"),
                    F.col("direct_like_tag_top_3"),
                    F.col("direct_dislike_tag_top_1"),
                    F.col("direct_dislike_tag_top_2"),
                    F.col("direct_dislike_tag_top_3"))
            .distinct()
    )
    return direct_tags_df

def sub_verified_tags(date, depth, spark, base_input_path):

    #проверенные тэги
    tags_verified_path = 'hdfs:///user/master/data/snapshots/tags_verified/actual'
    verified_tags = spark.read.parquet(tags_verified_path)

    #найдите сообщения в каналах за требуемую глубину
    paths_list = input_paths(base_input_path, date, depth)

    messages_in_chanels = spark.read.option("basePath", base_input_path)\
                            .parquet(*paths_list)\
                            .where("event_type='message' and event.message_channel_to is not null")\
                            .select("event.message_id", "event.channel_id", "event.tags")\
                            .withColumnRenamed("event.message_id", "message_id")\
                            .withColumnRenamed("event.channel_id","channel_id")\
                            .withColumnRenamed("event.tags","tags")


    #найдите пользователей, подписанных на канал (subscription_channel,user_id)
    #без фильтрации по дате
    subscriptions = spark.read.option("basePath", base_input_path)\
                    .parquet(base_input_path)\
                    .where("event_type='subscription'")\
                    .select("event.subscription_channel", "event.user")\
                    .withColumnRenamed("subscription_channel","channel_id")\
                    .withColumnRenamed("user","user_id")\
                    .distinct()


    #фильтрация по проверным тэгам и топ 1-3
    window = Window().partitionBy(F.col("user_id")).orderBy(
        F.col("tag_cnt").desc(), F.col("tag").desc())

    sub_verified_tags_df = (
                subscriptions
                    .join(messages_in_chanels, ["channel_id"], "inner")
                    .select(F.col("message_id"),
                            F.col("user_id"), 
                            F.explode(F.col("tags")).alias("tag"))
                    .join(verified_tags,["tag"],"inner")
                    .groupBy(["user_id", "tag"])
                    .agg(F.count("message_id").alias("tag_cnt"))
                    .withColumn("row_num", F.row_number().over(window))
                    .filter(F.col("row_num").isin([1, 2, 3]))
                    .groupBy("user_id")
                    .pivot("row_num")
                    .agg(F.first("tag"))
                    .withColumnRenamed("1", "sub_verified_tag_top_1")
                    .withColumnRenamed("2", "sub_verified_tag_top_2")
                    # .withColumnRenamed("3", "sub_verified_tag_top_3")                   
                    .withColumn("sub_verified_tag_top_3", F.lit("null"))
                    .select(F.col("user_id"),
                            F.col("sub_verified_tag_top_1"),
                            F.col("sub_verified_tag_top_2"),
                            F.col("sub_verified_tag_top_3"))
    )   

    return sub_verified_tags_df     

def connection_interests(date, depth, spark, base_input_path):

    direct_tags_df = direct_tags(date, depth, spark, base_input_path)
    direct_tags_df.cache()

    sub_verified_tags_df = sub_verified_tags(date, depth, spark, base_input_path)
    sub_verified_tags_df.cache()

    res_df = direct_tags_df.join(sub_verified_tags_df,["user_id"], "full_outer")
    
    return res_df

def main():

    # Получаем аргументы
    # date = sys.argv[1]
    # days_count = int(sys.argv[2])
    # events_base_path = sys.argv[3]
    # output_base_path = sys.argv[4]

    date = '2022-05-25'
    days_count = int(7)
    events_base_path = 'hdfs:///user/inthemidde/data/events' 
    output_base_path = 'hdfs:///user/inthemidde/data/analytics/connection_interests_d7'

    #/usr/lib/spark/bin/spark-submit --master yarn --deploy-mode cluster user_interests.py 2022-05-25 7 'hdfs:///user/inthemidde/data/events' 'hdfs:///user/maxalyapys/data/analytics/connection_interests_d7'

    #Создаем подклчение
    spark = SparkSession.builder\
            .config("spark.executor.memory", "20g")\
            .config("spark.executor.cores", 4)\
            .getOrCreate()

    #Расчет и запись результата
    connection_interests(date=date,
                         depth=days_count,
                         spark=spark,
                         base_input_path=events_base_path)\
        .write.mode("overwrite").parquet(f'{output_base_path}/date={date}')


main()
