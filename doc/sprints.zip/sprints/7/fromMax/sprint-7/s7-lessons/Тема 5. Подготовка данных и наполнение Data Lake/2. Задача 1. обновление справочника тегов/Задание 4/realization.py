def init():
    
    print('LOG - Init started')
    
    import os
    os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
    os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
    os.environ['JAVA_HOME']='/usr'
    os.environ['SPARK_HOME'] ='/usr/lib/spark'
    os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

    import findspark
    findspark.init()
    findspark.find()
    
    print('LOG - Init ended')

def main():
    
    print('LOG - Main started')
    
    from datetime import datetime, timedelta  
    from pyspark import SparkContext, SparkConf
    from pyspark.sql import SQLContext
    from pyspark.sql import SparkSession
    import pyspark.sql.functions as F
    
    
    #Подключение
    spark = SparkSession.builder \
                    .master("local[4]") \
                    .appName("Analyze") \
                    .getOrCreate()

    # Считываем имеющиеся tags
    df = spark.read.parquet(f'hdfs:///user/maxalyapys/data/analytics/candidates_d7_pyspark')
    df.describe().show()
    
    print('LOG - Main ended')

if __name__ == "__main__":
    
    init()
    
    main()