import airflow
import os 
# импортируем модуль os, который даёт возможность работы с ОС
# указание os.environ[…] настраивает окружение

from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import date, datetime

# прописываем пути
os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['JAVA_HOME']='/usr'
os.environ['SPARK_HOME'] ='/usr/lib/spark'
os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

# задаём базовые аргументы
default_args = {
    'start_date': datetime(2022, 6, 16),
    'owner': 'airflow'
}

# вызываем DAG
dag = DAG("verified_tags_candidates_d5_dag",
          schedule_interval=None,
          default_args=default_args
         )

spark_command = "spark-submit --master local[4] /lessons/verified_tags_candidates.py 2022-05-31 5 300 hdfs:///user/maxalyapys/data/events hdfs:///user/master/data/snapshots/tags_verified/actual hdfs:///user/maxalyapys/5.2.4/analytics/verified_tags_candidates_d5"

t1 = BashOperator(
    task_id='spark_job',
    task_concurrency = 2,
    bash_command=spark_command,
    retries=0,
    dag=dag
)

t1 