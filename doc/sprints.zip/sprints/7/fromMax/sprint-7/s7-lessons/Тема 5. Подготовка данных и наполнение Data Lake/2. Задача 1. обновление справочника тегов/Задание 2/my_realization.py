def init():
    
    print('LOG - Init started')
    
    import os
    os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
    os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
    os.environ['JAVA_HOME']='/usr'
    os.environ['SPARK_HOME'] ='/usr/lib/spark'
    os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

    import findspark
    findspark.init()
    findspark.find()
    
    print('LOG - Init ended')

def input_paths(date:str, depth:int) -> list():
    
    from datetime import datetime, timedelta  
    
    path_list = list()
    prod_dir = 'maxalyapys'
    for days_ago in range(depth):
        list_date = datetime.strptime(date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'hdfs:///user/{prod_dir}/data/events/date={list_date}/event_type=message'
        path_list.append(path_item)
    return path_list
 
def main():
    
    print('LOG - Main started')
    
    from datetime import datetime, timedelta  
    from pyspark import SparkContext, SparkConf
    from pyspark.sql import SQLContext
    from pyspark.sql import SparkSession
    import pyspark.sql.functions as F
    
    date = '2022-05-31'
    depth = 7
    tags_verified_path = 'hdfs:///user/master/data/snapshots/tags_verified/actual'
    
    #Подключение
    spark = SparkSession.builder \
                    .master("local[4]") \
                    .appName(f"Tag: date={date}, depth={depth}") \
                    .getOrCreate()

    # Считываем имеющиеся tags
    verified_tags = spark.read.parquet(tags_verified_path)
    #verified_tags.printSchema()
    #verified_tags.show(10)
    
    # Список директорий для чтения новых tags
    paths_list = input_paths(date,depth)
    #print(paths_list)
    messages = spark.read.parquet(*paths_list)
    #messages.printSchema()
    #messages.show(10)
    all_tags = messages.where("event.message_channel_to is not null")\
                    .selectExpr(["event.message_from as user", "explode(event.tags) as tag"])\
                    .groupBy("tag")\
                    .agg(F.expr("count(distinct user) as suggested_count"))\
                    .where("suggested_count >= 100")

    candidates = all_tags.join(verified_tags, "tag", "left_anti")

    # Директорию записи результата tag, suggested_count
    output_path = f'hdfs:///user/maxalyapys/data/analytics/candidates_d{depth}_pyspark'
    candidates.write.mode("overwrite").parquet(output_path)
    
    print('LOG - Main ended')

if __name__ == "__main__":
    
    init()
    
    main()
    