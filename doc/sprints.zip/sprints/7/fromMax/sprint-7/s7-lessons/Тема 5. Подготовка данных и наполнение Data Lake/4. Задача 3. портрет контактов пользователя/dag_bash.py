import airflow
import os 
# импортируем модуль os, который даёт возможность работы с ОС
# указание os.environ[…] настраивает окружение

from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import date, datetime

# прописываем пути
os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['JAVA_HOME']='/usr'
os.environ['SPARK_HOME'] ='/usr/lib/spark'
os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

# задаём базовые аргументы
default_args = {
    'start_date': datetime(2022, 6, 16),
    'owner': 'airflow'
}

# вызываем DAG
dag = DAG("connection_interest",
          schedule_interval=None,
          default_args=default_args
         )

t3 = BashOperator(
    task_id="connection_interests_d7",
    task_concurrency = 2,
    bash_command="$AIRFLOW_HOME/run_jobs.sh ",
    retries=0,
    dag=dag
)

t3