В терминале:
export PYSPARK_PYTHON=/usr/bin/python3
export HADOOP_CONF_DIR=/etc/hadoop/conf
export YARN_CONF_DIR=/etc/hadoop/conf
export JAVA_HOME=/usr
export SPARK_HOME=/usr/lib/spark
export PYTHONPATH=/usr/local/lib/python3.8

spark-submit --master yarn --deploy-mode cluster tags.py 2022-05-31 1 "hdfs:///user/master/data/snapshots/tags_verified/actual"