def init():
    
    print('LOG - Init started')
    
    import os
    os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
    os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
    os.environ['JAVA_HOME']='/usr'
    os.environ['SPARK_HOME'] ='/usr/lib/spark'
    os.environ['PYTHONPATH'] ='/usr/local/lib/python3.8'

    import findspark
    findspark.init()
    findspark.find()
    
    print('LOG - Init ended')

def input_paths(base_input_path, date, depth) -> list():
    
    from datetime import datetime, timedelta  
    
    path_list = list()
       
    for days_ago in range(depth):
        list_date = datetime.strptime(date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'{base_input_path}/date={list_date}/event_type=message'
        path_list.append(path_item)
    return path_list
 
def main():
    
    print('LOG - Main started')

    import sys

    from datetime import datetime, timedelta  
    from pyspark import SparkContext, SparkConf
    from pyspark.sql import SQLContext
    from pyspark.sql import SparkSession
    import pyspark.sql.functions as F
    
    date = str(sys.argv[1])                  #2022-05-31
    depth = int(sys.argv[2])                 #5
    cut = int(sys.argv[3])                   #300
    base_input_path = str(sys.argv[4])       #hdfs:///user/maxalyapys/data/events
    tags_verified_path = str(sys.argv[5])    #hdfs:///user/master/data/snapshots/tags_verified/actual
    base_output_path = str(sys.argv[6])      #hdfs:///user/maxalyapys/5.2.4/analytics/verified_tags_candidates_d5
    

    spark = SparkSession.builder \
                    .master("local[4]") \
                    .appName(f"VerifiedTagsCandidatesJob-[{date}]-d[{depth}]-cut[{cut}]") \
                    .getOrCreate()

    verified_tags = spark.read.parquet(tags_verified_path)
    
    paths_list = input_paths(base_input_path,date,depth)

    messages = spark.read.parquet(*paths_list)

    all_tags = (
        messages
            .where("event.message_channel_to is not null")
            .selectExpr(["event.message_from as user", "explode(event.tags) as tag"])
            .groupBy("tag")
            .agg(F.expr("count(distinct user) as suggested_count"))
            .where(f"suggested_count >= {cut}")
    )

    candidates = all_tags.join(verified_tags, "tag", "left_anti")
   
    candidates.write.mode("overwrite").parquet(f'{base_output_path}/date={date}')
    
    print('LOG - Main ended')

if __name__ == "__main__":
    
    init()
    
    main()