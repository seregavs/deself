from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from datetime import datetime, timedelta  

def input_paths(base_input_path, date, depth) -> list():  
    
    path_list = list()
    
    for days_ago in range(depth):
        list_date = datetime.strptime(date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'{base_input_path}/date={list_date}/event_type=message'
        path_list.append(path_item)
    return path_list

def tag_tops(date, depth, spark):
    
    base_input_path = 'hdfs:///user/maxalyapys/data/events'
    paths_list = input_paths(base_input_path, date, depth)
    
    messages = spark.read.parquet(*paths_list)

    user_tags = (
        messages
            .selectExpr(["event.message_id as message_id", "event.message_from as user_id", "explode(event.tags) as tag"])
            .groupBy(["user_id", "tag"])
            .agg(F.count("message_id").alias("tag_cnt"))
    )
    
    window = Window().partitionBy(F.col("user_id")).orderBy(F.col("tag_cnt").desc(), F.col("tag").desc())
    
    res_df = (
            user_tags
                .withColumn("row_num", F.row_number().over(window))
                .filter(F.col("row_num").isin([1,2,3]))
                .groupBy("user_id")
                .pivot("row_num")
                .agg(F.first("tag"))
                .withColumnRenamed("1", "tag_top_1")
                .withColumnRenamed("2", "tag_top_2")
                .withColumnRenamed("3", "tag_top_3")
    )
    
    return res_df

def main():
    spark = SparkSession.builder.getOrCreate()

    tag_tops('2022-06-04', 5, spark).repartition(1).write.mode("overwrite").parquet('hdfs:///user/maxalyapys/data/tmp/tag_tops_06_04_5')
    tag_tops('2022-05-04', 5, spark).repartition(1).write.mode("overwrite").parquet('hdfs:///user/maxalyapys/data/tmp/tag_tops_05_04_5')
    tag_tops('2022-05-04', 1, spark).repartition(1).write.mode("overwrite").parquet('hdfs:///user/maxalyapys/data/tmp/tag_tops_05_04_1')
    
main()

    