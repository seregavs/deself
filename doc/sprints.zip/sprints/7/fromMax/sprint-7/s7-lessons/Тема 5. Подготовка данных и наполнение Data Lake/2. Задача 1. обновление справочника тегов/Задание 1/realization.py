def input_paths(date:str, depth:int) -> list():

    from datetime import datetime, timedelta  
    
    path_list = list()
    prod_dir = 'maxalyapys'
    for days_ago in range(depth):
        list_date = datetime.strptime(date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'hdfs:///user/{prod_dir}/data/events/date={list_date}/event_type=message'
        path_list.append(path_item)
    return path_list


#path_list = input_paths(date = '2022-12-31', depth = 2)


        
    
