import pyspark
from pyspark.sql import SparkSession

def compare_df (df1, df2)->bool:
    return bool(
           df1.schema == df2.schema and
           df1.exceptAll(df2).count() + df2.exceptAll(df1).count() == 0 and
           df1.subtract(df2).count() + df2.subtract(df1).count() == 0
    )

