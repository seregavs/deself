import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from datetime import datetime, timedelta


def input_paths(base_input_path, date, depth) -> list():

    path_list = list()

    for days_ago in range(int(depth)):
        list_date = datetime.strptime(
            date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'{base_input_path}/date={list_date}'
        path_list.append(path_item)
    return path_list


def tag_tops(date, depth, spark, base_input_path):

    paths_list = input_paths(base_input_path, date, depth)

    messages = spark.read.option("basePath", base_input_path)\
                    .parquet(*paths_list)\
                    .where("event_type='message'")

    user_tags = (
        messages
        .select(F.col("event.message_id").alias("message_id"),
                F.col("event.message_from").alias("user_id"),
                F.explode(F.col("event.tags")).alias("tag"))
        .groupBy(["user_id", "tag"])
        .agg(F.count("message_id").alias("tag_cnt"))
    )

    window = Window().partitionBy(F.col("user_id")).orderBy(
        F.col("tag_cnt").desc(), F.col("tag").desc())

    res_df = (
        user_tags
        .withColumn("row_num", F.row_number().over(window))
        .filter(F.col("row_num").isin([1, 2, 3]))
        .groupBy("user_id")
        .pivot("row_num")
        .agg(F.first("tag"))
        .withColumnRenamed("1", "tag_top_1")
        .withColumnRenamed("2", "tag_top_2")
        .withColumnRenamed("3", "tag_top_3")
    )

    return res_df


def reaction_tag_tops(date, depth, spark, base_input_path):

    m_path = base_input_path
    r_paths_list = input_paths(base_input_path, date, depth)

    messages = spark.read.option("basePath", base_input_path)\
                    .parquet(m_path)\
                    .where("event_type='message'")

    reactions = spark.read.option("basePath", base_input_path)\
                     .parquet(*r_paths_list)\
                     .where("event_type='reaction'")

    liked_messages = (
        reactions
        .select(F.col("event.reaction_from").alias("user_id"),
                F.col("event.message_id").alias("message_id"),
                F.col("event.reaction_type").alias("reaction_type"))
        .filter(F.col("reaction_type") == 'like')
    )

    disliked_messages = (
        reactions
        .select(F.col("event.reaction_from").alias("user_id"),
                F.col("event.message_id").alias("message_id"),
                F.col("event.reaction_type").alias("reaction_type"))
        .filter(F.col("reaction_type") == 'dislike')
    )

    window = Window().partitionBy(F.col("user_id")).orderBy(
        F.col("tag_cnt").desc(), F.col("tag").desc())

    like_tag_df = (
        messages
        .filter(F.col('event.message_channel_to').isNotNull())
        .select(F.col("event.message_id").alias("message_id"),
                F.explode(F.col("event.tags")).alias("tag"))
        .join(liked_messages, ["message_id"], 'inner')
        .groupBy(["user_id", "tag"])
        .agg(F.count("message_id").alias("tag_cnt"))
        .withColumn("row_num", F.row_number().over(window))
        .filter(F.col("row_num").isin([1, 2, 3]))
        .groupBy("user_id")
        .pivot("row_num")
        .agg(F.first("tag"))
        .withColumnRenamed("1", "like_tag_top_1")
        .withColumnRenamed("2", "like_tag_top_2")
        .withColumnRenamed("3", "like_tag_top_3")
    )

    dislike_tag_df = (
        messages
        .filter(F.col('event.message_channel_to').isNotNull())
        .select(F.col("event.message_id").alias("message_id"),
                F.explode(F.col("event.tags")).alias("tag"))
        .join(disliked_messages, ["message_id"], 'inner')
        .groupBy(["user_id", "tag"])
        .agg(F.count("message_id").alias("tag_cnt"))
        .withColumn("row_num", F.row_number().over(window))
        .filter(F.col("row_num").isin([1, 2, 3]))
        .groupBy("user_id")
        .pivot("row_num")
        .agg(F.first("tag"))
        .withColumnRenamed("1", "dislike_tag_top_1")
        .withColumnRenamed("2", "dislike_tag_top_2")
        .withColumnRenamed("3", "dislike_tag_top_3")
    )

    res_df = (
        like_tag_df
        .join(dislike_tag_df, ['user_id'], "full_outer")
    )
    return res_df


def calculate_user_interests(date, depth, spark, base_input_path):

    df_top_user_tags = tag_tops(date, depth, spark, base_input_path)
    df_top_reaction_tags = reaction_tag_tops(
        date, depth, spark, base_input_path)

    res_df = (
        df_top_user_tags
        .join(df_top_reaction_tags, ['user_id'], "full_outer")
    )
    return res_df


def main():

    # Получаем аргументы
    date = sys.argv[1]
    days_count = int(sys.argv[2])
    events_base_path = sys.argv[3]
    output_base_path = sys.argv[4]

    #/usr/lib/spark/bin/spark-submit --master yarn --deploy-mode cluster user_interests.py 2022-05-04 5 'hdfs:///user/maxalyapys/data/events' 'hdfs:///user/maxalyapys/analytics/user_interests_d5'

    #Создаем подклчение
    spark = SparkSession.builder.master("yarn").getOrCreate()

    #Расчет и записи результата
    calculate_user_interests(date=date,
                             depth=days_count,
                             spark=spark,
                             base_input_path=events_base_path)\
        .write.mode("overwrite").parquet(f'{output_base_path}/date={date}')


main()
