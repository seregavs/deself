import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
from datetime import date, datetime, timedelta
from pyspark.sql.functions import substring


def get_geo(spark, base_geo_path='hdfs:///user/maxalyapys/data/geo/city'):
    '''
    Функция, возврающая датасет геопозицией городов
    '''
    geo_schema = StructType([
        StructField("id", IntegerType(), False), StructField(
            "city", StringType(), False),
        StructField("lat", StringType(), False), StructField(
            "lng", StringType(), False)
    ])

    geo = (
        spark.read.format("csv")
        .option("header", "true")
        .option("sep", ";")
        .schema(geo_schema)
        .load(base_geo_path)
        .withColumn("lat", F.regexp_replace("lat", ",", "."))
        .withColumn("lat", F.col("lat").cast("double"))
        .withColumn("lng", F.regexp_replace("lng", ",", "."))
        .withColumn("lng", F.col("lng").cast("double"))
    )

    return geo


def get_geo_with_tz(geo):
    '''
    Cписок городов, для которых напрямую определена зона
    функция from_utc_timestamp не падает в ошибку Py4JJavaError: Unknown time-zone ID
    '''
    geo_with_tz = geo.filter(F.col("id").isin([1, 2, 3, 4, 5, 8, 12, 17]))
    return geo_with_tz


def distance(lat1, lng1, lat2, lng2):
    '''
    Функция, возврающая расстояние в км
    '''
    lat1, lat2 = F.radians(lat1), F.radians(lat2)
    lng1, lng2 = F.radians(lng1), F.radians(lng2)
    r = F.lit(6371)
    A = F.pow(F.sin((lat2 - lat1)/F.lit(2)), 2)
    B = F.cos(lat1)*F.cos(lat2)*F.pow(F.sin((lng2 - lng1)/F.lit(2)), 2)
    return 2*r*F.asin(F.sqrt(A+B))


def get_user_pairs_from_same_channel(spark, date, base_events_path):
    '''
    Пары пользователей на базе подписки на общий канал
    '''
    user_subs = (
        spark.read.parquet(base_events_path)
        .filter((F.col("date") <= datetime.strptime(date, '%Y-%m-%d').date()) &
                (F.col("event_type") == 'subscription'))
        .select(F.col("event.user").alias("user_id"),
                F.col("event.subscription_channel").alias("channel_id"))
        .distinct()
    )

    user_pairs_from_same_channel = (
        user_subs.select(F.col("user_id").alias(
            "user_left"), F.col("channel_id"))
        .join(user_subs.select(F.col("user_id").alias("user_right"), F.col("channel_id")), ["channel_id"], 'inner')
        .filter(F.col("user_left") != F.col("user_right"))
        .select(F.col("user_left"),
                F.col("user_right"))
    )
    return user_pairs_from_same_channel


def get_exclude_pairs_from_direct_messages(spark, date, base_events_path):
    '''
    Переписки пользователей для исключения
    '''

    exclude_pairs_from_direct_messages = (
        spark.read.parquet(base_events_path)
        .filter((F.col("date") <= datetime.strptime(date, '%Y-%m-%d').date()) &
                (F.col("event_type") == 'message') &
                (F.col("event.message_to").isNotNull()))
        .select(F.col("event.message_from").alias("message_from"),
                F.col("event.message_to").alias("message_to"))
        .distinct()
    )
    return exclude_pairs_from_direct_messages


def get_last_user_message_on_date(spark, date, base_events_path):
    '''
    Последние сообщения пользователей за дату расчета с координатами
    '''
    last_user_message_on_date = (
        spark.read.parquet(base_events_path)
        .filter((F.col("date") == datetime.strptime(date, '%Y-%m-%d').date()) &
                (F.col("event_type") == 'message'))
        .select(F.col("event.message_from").alias("user_id"),
                F.col("event.message_ts").alias("message_ts"),
                F.col("lat").alias("message_lan"),
                F.col("lon").alias("message_lng"))
        .withColumn("rank_message_ts", F.row_number().over(Window.partitionBy("user_id").orderBy((F.col("message_ts").desc()))))
        .filter(F.col("rank_message_ts") == 1)
        .select(F.col("user_id"),
                F.col("message_ts"),
                F.col("message_lan"),
                F.col("message_lng"))
    )
    return last_user_message_on_date


def main(spark, date, base_events_path, base_output_path, close_dist):

    # пары пользователей на базе подписки на общий канал
    user_pairs_from_same_channel = get_user_pairs_from_same_channel(
        spark, date, base_events_path)

    # переписки пользователей для исключения
    exclude_pairs_from_direct_messages = get_exclude_pairs_from_direct_messages(
        spark, date, base_events_path)

    # последние сообщения пользователя за дату расчета date с координатами
    last_user_message_on_date = get_last_user_message_on_date(
        spark, date, base_events_path)

    # список городов
    geo = get_geo(spark)

    # список городов, для которых определяется временная зона
    geo_with_tz = get_geo_with_tz(geo)

    # формируем итоговую выборку
    res = (
        user_pairs_from_same_channel
        .join(exclude_pairs_from_direct_messages, (user_pairs_from_same_channel["user_left"] == exclude_pairs_from_direct_messages["message_from"]) &
              (user_pairs_from_same_channel["user_right"] == exclude_pairs_from_direct_messages["message_to"]), "leftanti")
        .select(F.col("user_left"), F.col("user_right"))
        .join(exclude_pairs_from_direct_messages, (user_pairs_from_same_channel["user_left"] == exclude_pairs_from_direct_messages["message_to"]) &
              (user_pairs_from_same_channel["user_right"] == exclude_pairs_from_direct_messages["message_from"]), "leftanti")
        .select(F.col("user_left"), F.col("user_right"))
        .join(last_user_message_on_date, F.col("user_left") == last_user_message_on_date["user_id"], 'inner')
        .select(F.col("user_left"),
                F.col("user_right"),
                F.col("message_lan").alias("user_left_lan"),
                F.col("message_lng").alias("user_left_lng"))
        .join(last_user_message_on_date, F.col("user_right") == last_user_message_on_date["user_id"], 'inner')
        .select(F.col("user_left"),
                F.col("user_right"),
                F.col("user_left_lan"),
                F.col("user_left_lng"),
                F.col("message_lan").alias("user_right_lan"),
                F.col("message_lng").alias("user_right_lng"),
                F.col("message_ts"))
        .withColumn("user_dist", distance(F.col("user_left_lan"), F.col("user_left_lng"), F.col("user_right_lan"), F.col("user_right_lng")))
        .filter(F.col("user_dist") <= close_dist)
        .crossJoin(geo.select(F.col("id"), F.col("lat"), F.col("lng"))) # для определения города zone_id
        .withColumn("dist", distance(F.col("user_right_lan"), F.col("user_right_lan"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("user_left", "user_right").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .select(F.col("user_left"),
                F.col("user_right"),
                F.col("user_left_lan"),
                F.col("user_left_lng"),
                F.col("user_right_lan"),
                F.col("user_right_lng"),
                F.col("message_ts"),
                F.col("id").alias("zone_id"))
        .crossJoin(geo_with_tz.select(F.col("city"), F.col("lat"), F.col("lng"))) # для определения времени local_time
        .withColumn("dist", distance(F.col("user_right_lan"), F.col("user_right_lan"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("user_left", "user_right").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .withColumn("local_time", F.from_utc_timestamp(F.col("message_ts"), F.concat(F.lit('Australia/'), F.col("city"))))
        .withColumn("processed_dttm", F.lit(datetime.strptime(date, '%Y-%m-%d')))
        .select(F.col("user_left"),
                F.col("user_right"),
                F.col("processed_dttm"),
                F.col("zone_id"),
                F.col("local_time"))
    )

    # пишем итог
    res.write.mode("overwrite").format("parquet").save(
        f"{base_output_path}/date={date}")


if __name__ == "__main__":

    # подключение к Spark
    spark = SparkSession.builder.getOrCreate()

    # считываем параметры
    date = sys.argv[1] 
    # '2022-05-25' 
    base_events_path = sys.argv[2]  
    # 'hdfs:///user/maxalyapys/data/geo/events'
    base_output_path = sys.argv[3]
    # 'hdfs:///user/maxalyapys/analytics/geo/geo_recomendation_mart'
    close_dist = int(sys.argv[4])
    # 1

    main(spark, date, base_events_path, base_output_path, close_dist)
