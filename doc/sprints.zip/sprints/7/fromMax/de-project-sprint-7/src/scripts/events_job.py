import sys

from pyspark.sql import SparkSession
import pyspark.sql.functions as F


def main():
    
    date = sys.argv[1]
    base_input_path = sys.argv[2]
    base_output_path = sys.argv[3]

    spark = SparkSession.builder.getOrCreate()

    events = spark.read.parquet(f"{base_input_path}/date={date}")

    events.write.partitionBy("event_type") \
        .mode("overwrite") \
        .format("parquet").save(f"{base_output_path}/date={date}")


if __name__ == "__main__":
    main()
