import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
from datetime import datetime, timedelta


def get_geo(spark, base_geo_path='hdfs:///user/maxalyapys/data/geo/city'):
    '''
    Функция, возврающая датасет геопозицией городов
    '''
    geo_schema = StructType([
        StructField("id", IntegerType(), False), StructField(
            "city", StringType(), False),
        StructField("lat", StringType(), False), StructField(
            "lng", StringType(), False)
    ])

    geo = (
        spark.read.format("csv")
        .option("header", "true")
        .option("sep", ";")
        .schema(geo_schema)
        .load(base_geo_path)
        .withColumn("lat", F.regexp_replace("lat", ",", "."))
        .withColumn("lat", F.col("lat").cast("double"))
        .withColumn("lng", F.regexp_replace("lng", ",", "."))
        .withColumn("lng", F.col("lng").cast("double"))
    )

    return geo


def get_geo_with_tz(geo):
    '''
    Cписок городов, для которых напрямую определена зона
    функция from_utc_timestamp не падает в ошибку Py4JJavaError: Unknown time-zone ID
    '''
    geo_with_tz = geo.filter(F.col("id").isin([1, 2, 3, 4, 5, 8, 12, 17]))
    return geo_with_tz


def distance(lat1, lng1, lat2, lng2):
    '''
    Функция, возврающая расстояние в км
    '''
    lat1, lat2 = F.radians(lat1), F.radians(lat2)
    lng1, lng2 = F.radians(lng1), F.radians(lng2)
    r = F.lit(6371)
    A = F.pow(F.sin((lat2 - lat1)/F.lit(2)), 2)
    B = F.cos(lat1)*F.cos(lat2)*F.pow(F.sin((lng2 - lng1)/F.lit(2)), 2)
    return 2*r*F.asin(F.sqrt(A+B))


def get_messages(spark, date, base_events_path):
    '''
    Функция, возвращает сообщения до расчетной даты включительно
    '''
    messages = (
        spark.read.parquet(base_events_path)
        .filter((F.col("date") <= datetime.strptime(date, '%Y-%m-%d').date()) & (F.col("event_type") == 'message'))
        .select(F.col("event.message_from").alias("user_id"),
                F.col("event.message_id").alias("message_id"),
                F.col("date"),
                F.col("event.message_ts").alias("message_ts"),
                F.col("lat").alias("message_lan"),
                F.col("lon").alias("message_lng"))
        # .filter(F.col("user_id") == '14117')  # тест
    )
    return messages


def get_messages_city(messages, geo):
    '''
    Возвращает актуальный адрес для сообщений пользователей (user_id, message_id, date, message_ts, city)
    '''
    messages_city = (
        messages
        .crossJoin(geo)
        .withColumn("dist", distance(F.col("message_lan"), F.col("message_lng"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("message_id").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .select(F.col("user_id"), F.col("message_id"), F.col("date"), F.col("message_ts"), F.col("city"))
        .orderBy(F.col("user_id"), F.col("message_ts").desc())
    )

    return messages_city


def get_user_act_city(messages_city):
    '''
    Возвращает актуальный адрес пользователей (user_id, act_city)
    '''

    w = Window().partitionBy(F.col("user_id")).orderBy(F.col("message_ts").desc())

    user_act_city = (
        messages_city
        .withColumn("act_city", F.first("city").over(w))
        .select(F.col("user_id"), F.col("act_city"))
        .distinct()
    )

    return user_act_city


def get_user_local_time(messages, geo_with_tz):
    '''
    Возвращает местное время (user_id, local_time)
    '''
    messages_cities_with_tz = get_messages_city(messages, geo_with_tz)

    w = Window().partitionBy(F.col("user_id")).orderBy(F.col("message_ts").desc())

    user_local_time = (
        messages_cities_with_tz
        .withColumn("last_city_with_tz", F.first("city").over(w))
        .withColumn("last_message_ts", F.first("message_ts").over(w))
        .withColumn("local_time", F.from_utc_timestamp(F.col("last_message_ts"), F.concat(F.lit("Australia/"), F.col("last_city_with_tz"))))
        .select(F.col("user_id"), F.col("local_time"))
        .distinct()
    )

    return user_local_time


def get_messages_from_travel(messages_city):
    '''
    Возвращает только собщения со сменой города
    '''

    w = Window().partitionBy(F.col("user_id")).orderBy(F.col("message_ts"))

    messages_from_travel = (
        messages_city
        .withColumn("lag_city", F.lag("city").over(w))
        .filter(F.col("city") != F.col("lag_city"))
        .select(F.col("user_id"), F.col("message_id"), F.col("date"), F.col("message_ts"), F.col("city"))
    )

    return messages_from_travel


def get_user_travel(messages_from_travel):
    '''
    Возвращает посещенные города и их количество пользователей (user_id, travel_array, travel_count)
    '''
    user_travel = (
        messages_from_travel
        .orderBy(F.col("user_id"), F.col("message_ts"))
        .groupBy(F.col("user_id"))
        .agg(F.collect_list(F.col("city")).alias("travel_array"))
        .select(F.col("user_id"),
                F.col("travel_array"),
                F.size(F.col("travel_array")).alias("travel_count"))
        .distinct()
    )

    return user_travel


def get_user_home_city(messages_from_travel, num_of_days):
    '''
    Возвращает домашний адрес, если он был найден (user_id, home_city)
    Домашний адрес - это последний город, в котором пользователь был дольше num_of_days дней.
    Критерий: между двумя сообщениями из разных мест с расчетной даты в прошлое больше num_of_days дней.
    Если не было сообщений в определенный день, то считаем что локация не менялась с прошлого раза
    '''
    w = Window().partitionBy(F.col("user_id")).orderBy(F.col("message_ts").desc())

    user_home_city = (
        messages_from_travel
        .withColumn("lead_date", F.lead("date").over(w))
        .withColumn("date_diff", F.datediff(F.col("date"), F.col("lead_date")))
        .filter(F.col("date_diff") > F.lit(num_of_days))
        .withColumn("home_city", F.first("city").over(w))
        .select(F.col("user_id"), F.col("home_city"))
        .distinct()
    )
    return user_home_city


def main(spark, date, base_events_path, base_output_path, num_of_days):

    # получаем сообщения до расчетной даты включительно
    messages = get_messages(spark, date, base_events_path)

    # список городов
    geo = get_geo(spark)

    # получаем список сообщений с городами
    messages_city = get_messages_city(messages, geo)

    # итоговая выборка [1.1]: актульный адрес
    user_act_city = get_user_act_city(messages_city)

    # итоговая выборка [1.2]: домашний город
    user_home_city = get_user_home_city(messages_city, num_of_days)

    # получаем список сообщений со сменой локации (города)
    messages_from_travel = get_messages_from_travel(messages_city)

    # итоговая выборка [2]: количество и список посещенных годов
    user_travel = get_user_travel(messages_from_travel)

    # список городов, для которых определяется временная зона
    geo_with_tz = get_geo_with_tz(geo)

    # итоговая выборка [3]: местное время
    user_local_time = get_user_local_time(messages, geo_with_tz)

    # итоговая выборка: [1.1] + [1.2] + [2] + [3]
    res = (
        user_act_city
        .join(user_home_city, ["user_id"], "full_outer")
        .join(user_travel, ["user_id"], "full_outer")
        .join(user_local_time, ["user_id"], "full_outer")
    )

    # пишем итог
    res.write.mode("overwrite").format("parquet").save(
        f"{base_output_path}/date={date}")


if __name__ == "__main__":

    # подключение к Spark
    spark = SparkSession.builder.getOrCreate()

    # считываем параметры
    date = sys.argv[1]
    # '2022-05-25'
    base_events_path = sys.argv[2]
    # 'hdfs:///user/maxalyapys/data/geo/events'
    base_output_path = sys.argv[3]
    # 'hdfs:///user/maxalyapys/analytics/geo/geo_user_mart'
    num_of_days = int(sys.argv[4])
    # 27

    main(spark, date, base_events_path, base_output_path, num_of_days)
