import sys
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
from datetime import date, datetime, timedelta
from pyspark.sql.functions import substring


def input_paths(base_input_path, date, depth):
    '''
    Функция, возврающая список директорий определенной глубины относитьно заданной даты и вида события
    '''
    path_list = list()

    for days_ago in range(int(depth)):
        list_date = datetime.strptime(
            date, '%Y-%m-%d').date() - timedelta(days=days_ago)
        path_item = f'{base_input_path}/date={list_date}'
        path_list.append(path_item)
    return path_list


def get_geo(spark, base_geo_path='hdfs:///user/maxalyapys/data/geo/city'):
    '''
    Функция, возврающая датасет геопозицией городов
    '''
    geo_schema = StructType([
        StructField("id", IntegerType(), False), StructField(
            "city", StringType(), False),
        StructField("lat", StringType(), False), StructField(
            "lng", StringType(), False)
    ])

    geo = (
        spark.read.format("csv")
        .option("header", "true")
        .option("sep", ";")
        .schema(geo_schema)
        .load(base_geo_path)
        .withColumn("lat", F.regexp_replace("lat", ",", "."))
        .withColumn("lat", F.col("lat").cast("double"))
        .withColumn("lng", F.regexp_replace("lng", ",", "."))
        .withColumn("lng", F.col("lng").cast("double"))
    )

    return geo


def distance(lat1, lng1, lat2, lng2):
    '''
    Функция, возврающая расстояние в км
    '''
    lat1, lat2 = F.radians(lat1), F.radians(lat2)
    lng1, lng2 = F.radians(lng1), F.radians(lng2)
    r = F.lit(6371)
    A = F.pow(F.sin((lat2 - lat1)/F.lit(2)), 2)
    B = F.cos(lat1)*F.cos(lat2)*F.pow(F.sin((lng2 - lng1)/F.lit(2)), 2)
    return 2*r*F.asin(F.sqrt(A+B))


def get_old_users(spark, date, base_events_path):
    '''
    Функция, возвращающая список "старых пользоватлей" на начало расчетного месяца от расчетой даты
    '''
    old_users = (
        spark.read.parquet(base_events_path)
        .filter((F.col("date") < datetime.strptime(date, '%Y-%m-%d').replace(day=1).date()) & (F.col("event_type") == 'message'))
        .select(F.col("event.message_from").alias("user_id"))
        .distinct()
    )
    return old_users


def get_month_event_statistics(spark, date, base_events_path, event_type, geo):
    '''
    Возвращает месячную статистику по событиям в зависимости от типа и даты расчетного периода
    '''

    # номер месяца
    month = datetime.strptime(date, '%Y-%m-%d').month
    month_depth = int(datetime.strptime(date, '%Y-%m-%d').day)
    month_paths_list = input_paths(base_events_path, date, month_depth)

    # сообщения по расчетному месяцу
    month_events = (
        spark.read.option("basePath", base_events_path)
        .parquet(*month_paths_list)
        .filter(F.col("event_type") == event_type)
        .select(
            F.col("event.message_from").alias("user_id"),
            F.col("lat").alias("message_lan"),
            F.col("lon").alias("message_lng")
        )
        .withColumn("event_num", F.row_number().over(Window.orderBy(F.lit('A'))))
        .crossJoin(geo)
        .withColumn("dist", distance(F.col("message_lan"), F.col("message_lng"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("event_num").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .withColumn("month", F.lit(month))
        .select(
            F.col("month"),
            F.col("event_num"),
            F.col("user_id"),
            F.col("id").alias("zone_id")
        )
        .groupBy(F.col("month"),
                 F.col("zone_id"))
        .agg(F.count("event_num").alias(f"month_{event_type}"))
    )
    return month_events


def get_week_event_statistics(spark, date, base_events_path, event_type, geo):
    '''
    Возвращает недельную статистику по событиям в зависимости от типа и даты расчетного периода
    '''
    # номер недели
    week = datetime.strptime(date, '%Y-%m-%d').isocalendar()[1]
    week_depth = int(datetime.strptime(date, '%Y-%m-%d').weekday()) + 1
    week_paths_list = input_paths(base_events_path, date, week_depth)

    # сообщения по расчетной неделе
    week_events = (
        spark.read.option("basePath", base_events_path)
        .parquet(*week_paths_list)
        .filter(F.col("event_type") == event_type)
        .select(
            F.col("event.message_from").alias("user_id"),
            F.col("lat").alias("message_lan"),
            F.col("lon").alias("message_lng")
        )
        .withColumn("event_num", F.row_number().over(Window.orderBy(F.lit('A'))))
        .crossJoin(geo)
        .withColumn("dist", distance(F.col("message_lan"), F.col("message_lng"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("event_num").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .withColumn("week", F.lit(week))
        .select(
            F.col("week"),
            F.col("event_num"),
            F.col("user_id"),
            F.col("id").alias("zone_id")
        )
        .groupBy(F.col("week"),
                 F.col("zone_id"))
        .agg(F.count("event_num").alias(f"week_{event_type}"))
    )
    return week_events


def get_month_user_statistics(spark, date, base_events_path, geo, old_users):
    '''
    Возвращает месячную статистику по новым пользователям
    '''

    # номер месяца
    month = datetime.strptime(date, '%Y-%m-%d').month
    month_depth = int(datetime.strptime(date, '%Y-%m-%d').day)
    month_paths_list = input_paths(base_events_path, date, month_depth)

    # сообщения по расчетному месяцу
    month_events = (
        spark.read.option("basePath", base_events_path)
        .parquet(*month_paths_list)
        .filter(F.col("event_type") == 'message')
        .select(
            F.col("event.message_from").alias("user_id"),
            F.col("event.message_ts").alias("message_ts"),
            F.col("lat").alias("message_lan"),
            F.col("lon").alias("message_lng"))
        .withColumn("rank_message_ts", F.row_number().over(Window.partitionBy("user_id").orderBy((F.col("message_ts")))))
        .filter(F.col("rank_message_ts") == 1)  # оставлем 1 первое сообщение для каждого пользователя 
        .join(old_users, ["user_id"], 'leftanti')  # исключаем старых
        .withColumn("event_num", F.row_number().over(Window.orderBy(F.lit('A'))))
        .crossJoin(geo)
        .withColumn("dist", distance(F.col("message_lan"), F.col("message_lng"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("event_num").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .withColumn("month", F.lit(month))
        .select(
            F.col("month"),
            F.col("event_num"),
            F.col("user_id"),
            F.col("id").alias("zone_id")
        )
        .groupBy(F.col("month"),
                 F.col("zone_id"))
        .agg(F.count("event_num").alias("month_user"))
    )
    return month_events


def get_week_user_statistics(spark, date, base_events_path, geo, old_users):
    '''
    Возвращает недельную статистику по новым пользователям
    '''

    # номер недели
    week = datetime.strptime(date, '%Y-%m-%d').isocalendar()[1]
    week_depth = int(datetime.strptime(date, '%Y-%m-%d').weekday()) + 1
    week_paths_list = input_paths(base_events_path, date, week_depth)

    # сообщения по расчетной неделе
    week_events = (
        spark.read.option("basePath", base_events_path)
        .parquet(*week_paths_list)
        .filter(F.col("event_type") == 'message')
        .select(
            F.col("event.message_from").alias("user_id"),
            F.col("event.message_ts").alias("message_ts"),
            F.col("lat").alias("message_lan"),
            F.col("lon").alias("message_lng"))
        .withColumn("rank_message_ts", F.row_number().over(Window.partitionBy("user_id").orderBy((F.col("message_ts")))))
        .filter(F.col("rank_message_ts") == 1)  # оставлем 1 первое сообщение для каждого пользователя
        .join(old_users, ["user_id"], 'leftanti')  # исключаем старых
        .withColumn("event_num", F.row_number().over(Window.orderBy(F.lit('A'))))
        .crossJoin(geo)
        .withColumn("dist", distance(F.col("message_lan"), F.col("message_lng"), F.col("lat"), F.col("lng")))
        .withColumn("rank_dist", F.row_number().over(Window.partitionBy("event_num").orderBy(F.col("dist"))))
        .filter(F.col("rank_dist") == 1)
        .withColumn("week", F.lit(week))
        .select(
            F.col("week"),
            F.col("event_num"),
            F.col("user_id"),
            F.col("id").alias("zone_id")
        )
        .groupBy(F.col("week"),
                 F.col("zone_id"))
        .agg(F.count("event_num").alias("week_user"))
    )
    return week_events


def main(spark, date, base_events_path, base_output_path):

    # список городов
    geo = get_geo(spark)

    # cписок старых пользователей
    old_users = get_old_users(spark, date, base_events_path)

    # получаем статистику по типам событий
    month_messages = get_month_event_statistics(
        spark, date, base_events_path, 'message', geo)
    month_reactions = get_month_event_statistics(
        spark, date, base_events_path, 'reaction', geo)
    month_subscriptions = get_month_event_statistics(
        spark, date, base_events_path, 'subscription', geo)
    month_users = get_month_user_statistics(
        spark, date, base_events_path, geo, old_users)

    week_messages = get_week_event_statistics(
        spark, date, base_events_path, 'message', geo)
    week_reactions = get_week_event_statistics(
        spark, date, base_events_path, 'reaction', geo)
    week_subscriptions = get_week_event_statistics(
        spark, date, base_events_path, 'subscription', geo)
    week_users = get_week_user_statistics(
        spark, date, base_events_path, geo, old_users)

    # формируем итоговую выборку, обработка null-значений показателей
    res = (
        month_messages
        .join(week_messages, ["zone_id"], "full_outer")
        .join(month_reactions, ["month", "zone_id"], "full_outer")
        .join(week_reactions, ["week", "zone_id"], "full_outer")
        .join(month_subscriptions, ["month", "zone_id"], "full_outer")
        .join(week_subscriptions, ["week", "zone_id"], "full_outer")
        .join(month_users, ["month", "zone_id"], "full_outer")
        .join(week_users, ["week", "zone_id"], "full_outer")
        .withColumn("week_message", F.coalesce("week_message", F.lit(0)))
        .withColumn("week_reaction", F.coalesce("week_reaction", F.lit(0)))
        .withColumn("week_subscription", F.coalesce("week_subscription", F.lit(0)))
        .withColumn("week_user", F.coalesce("week_user", F.lit(0)))
        .withColumn("month_message", F.coalesce("month_message", F.lit(0)))
        .withColumn("month_reaction", F.coalesce("month_reaction", F.lit(0)))       
        .withColumn("month_subscription", F.coalesce("month_subscription", F.lit(0)))
        .withColumn("month_user", F.coalesce("month_user", F.lit(0)))
        .select("month", "week", "zone_id",
                "week_message", "week_reaction", "week_subscription", "week_user",
                "month_message", "month_reaction", "month_subscription", "month_user")
    )

    # пишем итог
    s_year = datetime.strptime(date, '%Y-%m-%d').year
    s_month = datetime.strptime(date, '%Y-%m-%d').month
    s_week = datetime.strptime(date, '%Y-%m-%d').isocalendar()[1]

    res.write.mode("overwrite").format("parquet").save(
        f"{base_output_path}/year={s_year}/month={s_month}/week={s_week}")


if __name__ == "__main__":

    # подключение к Spark
    spark = SparkSession.builder.getOrCreate()

    # считываем параметры
    date = sys.argv[1]
    # '2022-05-25'
    base_events_path = sys.argv[2]  
    # 'hdfs:///user/maxalyapys/data/geo/events'
    base_output_path = sys.argv[3]
    # 'hdfs:///user/maxalyapys/analytics/geo/geo_statistics_mart'

    main(spark, date, base_events_path, base_output_path)
