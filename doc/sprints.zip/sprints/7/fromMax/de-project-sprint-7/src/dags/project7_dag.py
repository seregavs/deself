import airflow
import os
from airflow import DAG
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from datetime import date, datetime

# прописываем пути
os.environ['HADOOP_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['YARN_CONF_DIR'] = '/etc/hadoop/conf'
os.environ['JAVA_HOME'] = '/usr'
os.environ['SPARK_HOME'] = '/usr/lib/spark'
os.environ['PYTHONPATH'] = '/usr/local/lib/python3.8'

# задаём базовые аргументы
default_args = {
    'start_date': datetime(2022, 5, 25),
    'end_date': datetime(2022, 5, 25),
    'catchup': True,
    'max_active_runs': 2,
    'owner': 'maxalyapys'
}

# вызываем DAG
dag_spark = DAG("project7_dag",
                schedule_interval='0 0 * * *',
                default_args=default_args
                )

# поддерживается инкрементная загрузка и перезагрузка исторический данных
date = '{{ ds }}'

geo_events_partitioned = SparkSubmitOperator(
    task_id="geo_events_partitioned",
    task_concurrency=2,
    dag=dag_spark,
    application="/lessons/scripts/events_job.py",
    conn_id="yarn_spark",
    application_args=[date, "hdfs:///user/master/data/geo/events","hdfs:///user/maxalyapys/data/geo/events"]
)

geo_user_mart = SparkSubmitOperator(
    task_id="geo_user_mart",
    task_concurrency=2,
    dag=dag_spark,
    application="/lessons/scripts/geo_user_mart.py",
    conn_id="yarn_spark",
    application_args=[date, "hdfs:///user/maxalyapys/data/geo/events","hdfs:///user/maxalyapys/analytics/geo/geo_user_mart", 27]
)

geo_recommendation_mart = SparkSubmitOperator(
    task_id="geo_recommendation_mart",
    task_concurrency=2,
    dag=dag_spark,
    application="/lessons/scripts/geo_recommendation_mart.py",
    conn_id="yarn_spark",
    application_args=[date, "hdfs:///user/maxalyapys/data/geo/events","hdfs:///user/maxalyapys/analytics/geo/geo_recommendation_mart", 1]
)

geo_statistics_mart = SparkSubmitOperator(
    task_id="geo_statistics_mart",
    task_concurrency=2,
    dag=dag_spark,
    application="/lessons/scripts/geo_statistics_mart.py",
    conn_id="yarn_spark",
    application_args=[date, "hdfs:///user/maxalyapys/data/geo/events","hdfs:///user/maxalyapys/analytics/geo/geo_statistics_mart"]
)

geo_events_partitioned >> [geo_user_mart, geo_recommendation_mart, geo_statistics_mart]
