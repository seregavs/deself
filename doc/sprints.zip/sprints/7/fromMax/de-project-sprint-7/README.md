# Проект 7-го спринта

### Описание
Репозиторий предназначен для сдачи проекта 7-го спринта

### Как работать с репозиторием
1. В вашем GitHub-аккаунте автоматически создастся репозиторий `de-project-sprint-7` после того, как вы привяжете свой GitHub-аккаунт на Платформе.
2. Скопируйте репозиторий на свой компьютер. В качестве пароля укажите ваш `Access Token`, который нужно получить на странице [Personal Access Tokens](https://github.com/settings/tokens)):
	* `git clone https://github.com/{{ username }}/de-project-sprint-7.git`
3. Перейдите в директорию с проектом: 
	* `cd de-project-sprint-7`
4. Выполните проект и сохраните получившийся код в локальном репозитории:
	* `git add .`
	* `git commit -m 'my best commit'`
5. Обновите репозиторий в вашем GutHub-аккаунте:
	* `git push origin main`

### Структура репозитория
Вложенные файлы в репозиторий будут использоваться для проверки и предоставления обратной связи по проекту. Поэтому постарайтесь публиковать ваше решение согласно установленной структуре — так будет проще соотнести задания с решениями.

Внутри `src` расположены две папки:
- `/src/dags`;
- `/src/script`.

Необходимо создать соединение в Airflow с параметрами:
- conn_id = yarn_spark
- conn_type = spark
- host = yarn

Структура:
Директория для аналитиков: 
- `hdfs:///user/maxalyapys/analytics/geo/geo_user_mart` - витрина по пользователям
- `hdfs:///user/maxalyapys/analytics/geo/geo_statistics_mart` - витрина в разрезе зон
- `hdfs:///user/maxalyapys/analytics/geo/geo_recomendation_mart` - витрина по рекомендациям

Директория детальных данных: 
- `/user/maxalyapys/data/geo/events` - детальные данные events в формате .parquet партиции по `date` и по `event_type`
- `/user/maxalyapys/data/geo/city` - детальные геоданные city в .csv. 

 Загружены разово командой
- !hdfs dfs -mkdir -p hdfs:///user/maxalyapys/data/geo/city
- !hdfs dfs -copyFromLocal /lessons/geo.csv hdfs:///user/maxalyapys/data/geo/city

Директория для стейджинга:
- `/user/master/data/geo/events` - исходные данный events в формате .parquet партиции по `date`

Песочница: 
- `/user/maxalyapys/tmp`

