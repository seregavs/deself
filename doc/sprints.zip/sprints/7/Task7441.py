#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pyspark
from pyspark.sql import SparkSession


# In[3]:


spark = SparkSession.builder \
                    .master("yarn") \
                    .appName("Learning DataFrames") \
                    .getOrCreate()


# In[4]:


data = [ ('Max',55),('Yan',53), ('Dmitry', 54), ('Ann',25) ]
columns = ['Name', 'Age' ]


# In[5]:


df = spark.createDataFrame(data=data, schema=columns)


# In[7]:


df.printSchema()

