import logging
import boto3
import pendulum
from airflow.decorators import dag, task
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
import pandas as pd
from datetime import datetime
import vertica_python
# import sqlalchemy as sa
import contextlib

log = logging.getLogger(__name__)

# default_args = {
#     'start_date':   datetime(2022, 10, 1),
#     'end_date':     datetime(2022, 11, 30),
#     'catchup':      True,
#     'max_active_runs': 2,
#     'owner':        'inthemidde'
# }

# dag_spark = DAG("main_dag",
#                 schedule_interval='0 0 * * *',
#                 default_args=default_args
#                 )

@dag(
    schedule_interval='1 0 * * *',  # Задаем расписание выполнения дага - once a day at 00:01:00
    start_date=pendulum.datetime(2022, 10, 1, tz="UTC"),  # Дата начала выполнения дага.
    catchup=True,  # Нужно ли запускать даг за предыдущие периоды (с start_date до сегодня) - False (не нужно).
    tags=['prj_final'],  # Теги, используются для фильтрации в интерфейсе Airflow.
    is_paused_upon_creation=False  # Остановлен/запущен при появлении. Сразу запущен.
)

def dag_de_stg_final():

    postgres_conn_id = 'postgres_src'
    # vertica_conn_info = {'host': 'vertica.tgcloudenv.ru', 'port': '5543', 'database': 'dwh',
    #                      'user': 'stv2023070317', 'password': 'WRGXLRoVRxgmSh6'}
    # ldate = datetime.now().date()
    ldate = '2022-10-10'
    schema ='STV2023070317'

    vertica_conn = vertica_python.connect(
        host='vertica.tgcloudenv.ru',
        port='5433',
        user='stv2023070317',
        password = 'WRGXLRoVRxgmSh6', 
        database = 'dwh'
    )

    def stg_load_currency(ds):
        # Init section
        # ldate = '2022-10-05'
        # ldate = ds
        columns = ['date_update', 'currency_code', 'currency_code_with', 'currency_with_div']
        columns = ', '.join(columns)
        table = 'currencies'
        copy_expr = f"""
        COPY {schema}__STAGING.{table} ({columns}) FROM STDIN DELIMITER ',' ENCLOSED BY '"'
        """

        log.info(f'Load { table } from Postgre to Vertica for date = { ldate }')
        postgres_hook = PostgresHook(postgres_conn_id)
        engine_pg = postgres_hook.get_sqlalchemy_engine()
        log.info(f'Connected to Postgre: { engine_pg }')
        df = pd.read_sql(f"select { columns } from public.{ table } " +
                         f"where date_update::date = '{ ldate }'",engine_pg)
        num_rows = len(df)
        log.info(f'Read Posgtres, table { table }, rows={ num_rows }')
        chunk_size = num_rows // 10 # // operator divides the first number by the second number and rounds the result down to the nearest integer (or whole number).
        # row_count = df.to_sql(pg_table, engine, schema=pg_schema, if_exists='append', index=False)
        # logging.info(f'{row_count} rows was inserted')
        # engine_vt = sa.create_engine('vertica+vertica_python://stv2023070317:WRGXLRoVRxgmSh6@vertica.tgcloudenv.ru:5433/dwh')
        # log.info(f'Connected to Vertica: { engine_vt }')
        # vertica_conn = vertica_python.connect(**vertica_conn_info)
        with contextlib.closing(vertica_conn.cursor()) as cur:            
            start = 0
            k = cur.execute(operation=f"DELETE FROM { schema }__STAGING.{table} WHERE date_update::date = '{ ldate }';")
            log.info(f'Deleted { k.rowcount } from { table }')
            # log.info(str(k))
            while start <= num_rows:
                end = min(start + chunk_size, num_rows)
                log.info(f"loading rows ({table}) -> Vertica {start}-{end}")
                df.loc[start: end].to_csv('/tmp/chunk.csv', index=False)
                with open('/tmp/chunk.csv', 'rb') as chunk:
                    cur.copy(copy_expr, chunk, buffer_size=65536)
                vertica_conn.commit()
                start += chunk_size + 1
        vertica_conn.close()  

    def stg_load_transactions(ds):
        # Init section
        # ldate = '2022-10-05'
        # ldate = ds
        columns = [ 'operation_id', 'account_number_from', 'account_number_to', 'currency_code',
                    'country', 'status', 'transaction_type', 'amount', 'transaction_dt']
        columns = ', '.join(columns)
        table = 'transactions'
        copy_expr = f"""
        COPY {schema}__STAGING.{table} ({columns}) FROM STDIN DELIMITER ',' ENCLOSED BY '"'
        """

        log.info(f'Load { table } from Postgre to Vertica for date { ldate }')
        postgres_hook = PostgresHook(postgres_conn_id)
        engine_pg = postgres_hook.get_sqlalchemy_engine()
        log.info(f'Connected to Postgre: { engine_pg }')
        df = pd.read_sql(f"select { columns } from public.{ table } " +
                         f"where transaction_dt::DATE = '{ ldate }'",engine_pg)
        num_rows = len(df)
        log.info(f'Read Posgtres, table { table }, rows={ num_rows }')
        chunk_size = num_rows // 10

        with contextlib.closing(vertica_conn.cursor()) as cur:            
            start = 0
            k = cur.execute(operation=f"DELETE FROM { schema }__STAGING.{table} WHERE transaction_dt::DATE = '{ ldate }';")
            log.info(f'Deleted { k.rowcount } from { table }')
            while start <= num_rows:
                end = min(start + chunk_size, num_rows)
                log.info(f"loading rows ({table}) -> Vertica {start}-{end}")
                df.loc[start: end].to_csv('/tmp/chunk.csv', index=False)

                with open('/tmp/chunk.csv', 'rb') as chunk:
                    cur.copy(copy_expr, chunk, buffer_size=65536)
                vertica_conn.commit()
                start += chunk_size + 1
        vertica_conn.close() 


    start_task = DummyOperator(task_id="start_task")

    task_currency = PythonOperator(
        task_id='task_currency',
        python_callable=stg_load_currency,
    )

    task_trans = PythonOperator(
        task_id='task_trans',
        python_callable=stg_load_transactions,
    )

    # start_task >> task_currency
    start_task >> task_trans >> task_currency

dag = dag_de_stg_final()