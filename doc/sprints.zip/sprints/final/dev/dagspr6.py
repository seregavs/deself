import logging
import boto3
import pendulum
from airflow.decorators import dag, task
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
import pandas as pd
import vertica_python
import sqlalchemy as sa

log = logging.getLogger(__name__)
# conn_info = {'host': 'vertica.tgcloudenv.ru', 
#              'port': '5433',
#              'user': 'stv2023070317',       
#              'password': 'WRGXLRoVRxgmSh6',
#              'database': 'dwh',
#             'autocommit': True
# }

dtype_set = {'group_log': {'group_id':int,'user_id':int,'user_id_from':int,'event':str, 'datetime': str } }
conv_set  = {'group_log': {'user_id_from':lambda x: pd.NA if x == '' else int(x)} }

@dag(
    schedule_interval='0/45 * * * *',  # Задаем расписание выполнения дага - каждый 15 минут.
    start_date=pendulum.datetime(2021, 5, 5, tz="UTC"),  # Дата начала выполнения дага. Можно поставить сегодня.
    catchup=False,  # Нужно ли запускать даг за предыдущие периоды (с start_date до сегодня) - False (не нужно).
    tags=['spr6'],  # Теги, используются для фильтрации в интерфейсе Airflow.
    is_paused_upon_creation=True  # Остановлен/запущен при появлении. Сразу запущен.
)

def spr6_dagprg():

    AWS_ACCESS_KEY_ID = "YCAJEWXOyY8Bmyk2eJL-hlt2K"
    AWS_SECRET_ACCESS_KEY = "YCPs52ajb2jNXxOUsL4-pFDL1HnV2BCPd928_ZoA"
    bucket_files = ['group_log']
    start_task = DummyOperator(task_id="start_task")

    def fetch_s3_file(bucket: str, key: str):
        session = boto3.session.Session()
        s3_client = session.client(
            service_name='s3',
            endpoint_url='https://storage.yandexcloud.net',
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        )
        s3_client.download_file(
            Bucket=str(bucket),
            Key=key,
            Filename=f'/data/{key}.csv'
        )
        log.info(f"downloaded {key}!")

    def load_to_table(key: str):
        df = pd.read_csv(filepath_or_buffer = f'/data/{key}.csv', sep=','
                        ,dtype      = dtype_set['group_log']
                        ,converters = conv_set['group_log'])
        df['datetime'] = pd.to_datetime(df['datetime'])
        log.info(df)
        engine = sa.create_engine('vertica+vertica_python://stv2023070317:WRGXLRoVRxgmSh6@vertica.tgcloudenv.ru:5433/dwh')
        df.to_sql(key, engine, index=False, if_exists='append', schema='STV2023070317__STAGING')

# df_group_log['user_id_from'] = pd.array(df_group_log['user_id_from'], dtype="Int64").

    task0 = PythonOperator(
        task_id=bucket_files[0],
        python_callable=fetch_s3_file,
        op_kwargs={'bucket': 'sprint6', 'key': bucket_files[0]},
    )

    task1 = PythonOperator(
        task_id=f'{bucket_files[0]}_table',
        python_callable=load_to_table,
        op_kwargs={'key': bucket_files[0]},
    )

    # Далее задаем последовательность выполнения тасков.
    start_task >> task0 >> task1 # type: ignore

dag = spr6_dagprg()