 insert into STV2023070317__DWH.global_metrics (
 select v1.date_update, v1.currency_code, v1.amount_total, v1.cnt_transactions
     , v2.avg_transactions_per_account, v2.cnt_accounts_make_transactions
  from
 (select date_update, currency_code
     , s_amount*currency_with_div as amount_total
     , cnt_transactions
  from (
	select v2.date_update, v2.currency_code, s_amount, currency_with_div, cnt_transactions
	     , row_number () over (partition by v2.currency_code, v2.date_update order by v1.date_update desc)  as rn
	  from
		 (select date_update::date, currency_code, currency_code_with, currency_with_div
		    from STV2023070317__STAGING.currencies
		   where currency_code_with = 420
		   union all
		  select distinct date_update::date, 420 as currency_code, 420 as currency_code_with, 1 as currency_with_div
		    from STV2023070317__STAGING.currencies) v1,
		(select transaction_dt::date as date_update
		     , currency_code
		     , country
		     , sum(amount) as s_amount
		     , count(*) as cnt_transactions
		  from STV2023070317__STAGING.transactions
		 group by transaction_dt::date, currency_code, country) v2
	 where v1.currency_code = v2.currency_code
	   and v2.date_update >= v1.date_update ) v0
 where rn = 1
   and date_update = '{{ds}}') v1,
 (select date_update, currency_code, round(avg(s_amount),2) as avg_transactions_per_account
      , count(distinct account_number_from) as cnt_accounts_make_transactions
   from (
 select transaction_dt::date as date_update, currency_code
      , account_number_from, sum(amount)  as s_amount
   from  STV2023070317__STAGING.transactions
  where transaction_dt::date = '{{ds}}'
  group by transaction_dt::date, currency_code, account_number_from ) v1
  group by date_update, currency_code ) v2
 where v1.date_update = v2.date_update
   and v1.currency_code = v2.currency_code )

--Дата передается извне {{ds}}
--Предполагается, что курс пересчета валюты действует на все даты в будущее, считая от даты date_update, до определения записи с более поздней датой.
--Например, если в таблице определены курсы только на даты 2022-06-01 и 2022-06-03, то курс на 2022-06-02 такой же как и на 2022-06-01, а уже на 
--2022-06-03 курс будет другой.
--Для реализации этой логики использется NON-EQUI-JOIN v2.date_update >= v1.date_update и дальнейшее 
-- фильтр по полю row_number () over (partition by v2.currency_code, v2.date_update order by v1.date_update desc) = 1

-- 420 - код USD, к этой валюте выполняется пересчет в amount_total
-- для NON-EQUI-JOIN добавлена суррогатная запись пересчета из 420 в 420

create or replace view STV2023070317__DWH.v_global_metrics as
 select t1.date_update::date as date_update
      , t1.currency_from
      , t2.country
      , amount_total as amount_total
      , cnt_transactions as cnt_transactions
      , avg_transactions_per_account as avg_transactions_per_account
      , cnt_accounts_make_transactions as cnt_accounts_make_transactions
   from STV2023070317__DWH.global_metrics as t1
      ,(select distinct currency_code, country from STV2023070317__STAGING.transactions) as t2
  where t1.currency_from  = t2.currency_code