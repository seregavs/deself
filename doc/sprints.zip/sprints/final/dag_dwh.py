import logging
import pendulum
from airflow.decorators import dag, task
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
import vertica_python
import contextlib

log = logging.getLogger(__name__)

@dag(
    schedule_interval='10 0 * * *',  # Задаем расписание выполнения дага - once a day at 00:10:00
    start_date=pendulum.datetime(2022, 10, 1, tz="UTC"),  # Дата начала выполнения дага. Можно поставить сегодня.
    catchup=False,  # Нужно ли запускать даг за предыдущие периоды (с start_date до сегодня) - False (не нужно).
    tags=['prj_final'],  # Теги, используются для фильтрации в интерфейсе Airflow.
    is_paused_upon_creation=False  # Остановлен/запущен при появлении. Сразу запущен.
)

def dag_de_dwh_final():

    ldate = datetime.now().date()
    ldate = '2022-10-10'
    schema ='STV2023070317'

    vertica_conn = vertica_python.connect(
        host='vertica.tgcloudenv.ru',
        port='5433',
        user='stv2023070317',
        password = 'WRGXLRoVRxgmSh6', 
        database = 'dwh'
    )

    def dwh_load_gm():
        # Init section
        table = 'global_metrics'
        insert_expr = f"""
            insert into { schema }__DWH.{ table } 
                (select v1.date_update::date as date_update, v1.currency_code, t2.country, round(v1.amount_total/100,0) as amount_total
                    , round(v1.cnt_transactions/100,0) as cnt_transactions
                    , round(v2.avg_transactions_per_account/100,0) as avg_transactions_per_account
                    , v2.cnt_accounts_make_transactions
                from
                -- Блок1
                --	amount_total — общая сумма транзакций по валюте в долларах;
                --	cnt_transactions — общий объём транзакций по валюте;
                    (select date_update, currency_code
                        , round(s_amount*currency_with_div,2) as amount_total -- пересчет в долллары
                        , cnt_transactions
                        from 
                        (select v2.date_update, v2.currency_code, s_amount, currency_with_div, cnt_transactions
                                , row_number () over (partition by v2.currency_code, v2.date_update order by v1.date_update desc)  as rn
                                -- rn - номер строки, уникальный внутри даты и валюты, с наибольшей двтой курса валютной пары
                                -- чтобы взять наиболее свежий курс валютной пары на дату транзакции
                            from
                                (select date_update::date, currency_code, currency_code_with, currency_with_div
                                    from { schema }__STAGING.currencies
                                where currency_code_with = 420
                                union all
                                select distinct date_update::date, 420 as currency_code, 420 as currency_code_with, 1 as currency_with_div
                                    from { schema }__STAGING.currencies) v1, -- валютные пары с долларом (420), включая пару доллар-доллар
                                (select transaction_dt::date as date_update
                                    , currency_code
                                    , country
                                    , sum(amount) as s_amount      -- подсчет суммы транзакций в валюте транзакции для последующей конвертации в USD
                                    , sum(amount) as cnt_transactions -- подсчет суммы транзакций в валюте транзакции (странное имя предлагается для поля - cnt.., поэтому отдельно)
                                from { schema }__STAGING.transactions
                                where transaction_type <> 'authorization' -- исключаются записи о проверке авторизации (эта процедура не связана с движением денег)
                                group by transaction_dt::date, currency_code, country) v2 -- группировка транзакций по дате, стране и валюте
                            where v1.currency_code = v2.currency_code  -- соединение валютных пар и тразакций по валюте
                            and v2.date_update >= v1.date_update ) v0 -- и по дате действия курса валютной пары
                        where rn = 1 -- фильтр, чтобы получить пересчет по самой актуальному курсу (но не позднее даты транзакции)
                            and date_update = '{ldate}') v1,
                -- Блок 2
                --	avg_transactions_per_account — средний объём транзакций с аккаунта;
                --	cnt_accounts_make_transactions — количество уникальных аккаунтов с совершёнными транзакциями по валюте.		     
                    (select date_update, currency_code
                        , round(avg(s_amount),2) as avg_transactions_per_account -- подсчет средней величины транзакции за дату и по валюте
                        , count(distinct account) as cnt_accounts_make_transactions -- подсчет кол-ва уникальных контргентов за дату и по валюте
                    from -- агрегирование данных по дате транзакции, валюте и контрагентам, неважно были ли они отрправителями или получателями
                        (select date_update, account, currency_code, sum(s_amount) as s_amount from
                        -- получение списка на дату и по валюте всех сумм по контрагентам, когда они были
                        -- отправителями или получателями средcтв
                            (select transaction_dt::date as date_update, currency_code
                                , account_number_from as account
                                , sum(amount)  as s_amount
                            from { schema }__STAGING.transactions
                            where transaction_dt::date = '{ldate}'
                                and transaction_type <> 'authorization'
                                and account_number_from <> - 1
                            group by transaction_dt::date, currency_code, account_number_from
                            union ALL 
                            select transaction_dt::date as date_update, currency_code
                                , account_number_to as account, sum(amount)  as s_amount
                            from { schema }__STAGING.transactions
                            where transaction_dt::date = '{ldate}'
                                and transaction_type <> 'authorization'
                                and account_number_to <> - 1
                            group by transaction_dt::date, currency_code, account_number_to ) v0
                            group by date_update, account, currency_code ) v1
                    group by date_update, currency_code ) v2,
                    (select distinct currency_code, country from STV2023070317__STAGING.transactions) as t2
                -- inner join Блока1 и Блока2
                where v1.date_update = v2.date_update
                and v1.currency_code = v2.currency_code
                and v1.currency_code = t2.currency_code)
        """

        with contextlib.closing(vertica_conn.cursor()) as cur:            
            k = cur.execute(operation=f"DELETE FROM { schema }__DWH.{table} WHERE date_update::DATE = '{ ldate }';")
            log.info(f'Deleted { k.rowcount } from { table }')
            k = cur.execute(operation=insert_expr)
            log.info(f'Inserted { k.rowcount } into { table }')
        vertica_conn.commit()
        vertica_conn.close() 
        
    start_task = DummyOperator(task_id="start_task")
    task_gm = PythonOperator(
        task_id='task_gm',
        python_callable=dwh_load_gm,
    )

    start_task >> task_gm

dag = dag_de_dwh_final()