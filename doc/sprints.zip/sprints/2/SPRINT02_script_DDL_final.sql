-- Исправьте ошибки в этом скрипте

-- Создание таблиц
drop table if exists public.d_categories cascade;
CREATE TABLE public.d_categories(
   category_id  SERIAL8 ,
   name_category TEXT ,
   description  TEXT ,
   PRIMARY KEY  (category_id)
);
CREATE INDEX category_id_index ON public.d_categories (category_id);
/*
CREATE TABLE public.d_products(
   product_id   SERIAL,
   category_id  BIGINT ,
   nameproduct  TEXT ,
   stock        BOOLEAN,
   PRIMARY KEY (product_id),
   FOREIGN KEY (category_id) REFERENCES d_categories(category_id) ON UPDATE CASCADE
);
*/
CREATE TABLE public.d_buckets(
   bucket_id    SERIAL8 ,
   order_id     BIGINT ,
   product_id   BIGINT ,
   num          NUMERIC(14,2),
   PRIMARY KEY (bucket_id),
   FOREIGN KEY (product_id) REFERENCES d_products(product_id) ON UPDATE CASCADE
);
CREATE INDEX bucket_id_index ON public.d_buckets (bucket_id);

CREATE TABLE public.d_orders(
   order_id     BIGINT ,
   client_id    BIGINT,
   payment      NUMERIC(14,2),
   hitdatetime  TIMESTAMP,
   PRIMARY KEY (order_id),
   FOREIGN KEY (client_id) REFERENCES user_attributes(client_id) ON UPDATE CASCADE
);
CREATE INDEX order_id_index ON public.d_orders (order_id);
-- Миграция данных

INSERT INTO public.d_categories
(namecategory, description)
SELECT DISTINCT category[1] AS namecategory ,
                            category[2] AS description
FROM (
      SELECT (regexp_split_to_array(category , E'\\:+')) AS category
      FROM orders_attributes oa) AS parse_category;

INSERT INTO public.d_products
(product_id, category_id, nameproduct, stock)
SELECT DISTINCT oa.itemcode as product_id,
       dc.category_id AS category_id,
       (regexp_split_to_array(oa.description, E'\\:+'))[1] AS nameproduct,
       oa.stock AS stock
FROM (
      SELECT *, (regexp_split_to_array(category, E'\\:+'))[1] AS namecategory
      FROM orders_attributes
    ) as oa
RIGHT JOIN d_categories dc ON oa.namecategory = dc.namecategory;

INSERT INTO public.d_buckets
(product_id, order_id, num)
SELECT
    itemcode as product_id,
    order_id as order_id,
    num
FROM orders_attributes;

INSERT INTO public.d_orders
(order_id, client_id, payment, hitdatetime)
SELECT DISTINCT
  oa.order_id AS order_id,
  oa.client_id AS client_id,
  oa.payment_amount,
  datetime AS hitdatetime
FROM orders_attributes oa;
-- **************************************
--d_clients
CREATE TABLE public.d_clients(
   client_id    BIGINT ,
   first_name   text ,
   last_name    text ,
   utm_campaign VARCHAR(30),
   PRIMARY KEY  (client_id)
);
CREATE INDEX client_id_index ON public.d_clients(client_id);

--d_user_payment_log
CREATE TABLE public.d_user_payment_log(
   payment_log_id   BIGINT ,
   client_id      	BIGINT ,
   hit_date_time    TIMESTAMP ,
   action           VARCHAR(20),
   payment_amount   NUMERIC(14,2),
   PRIMARY KEY 		(payment_log_id),
   FOREIGN KEY 		(client_id) REFERENCES d_clients(client_id) ON UPDATE cascade
);
CREATE INDEX user_payment_log_id_index  ON public.d_user_payment_log (payment_log_id);

--d_user_activity_log
CREATE TABLE public.d_user_activity_log(
   activity_id    BIGINT ,
   client_id      BIGINT ,
   hit_date_time  TIMESTAMP ,
   action         VARCHAR(20),
   PRIMARY KEY  (activity_id),
   FOREIGN KEY  (client_id) REFERENCES d_clients(client_id) ON UPDATE cascade
);
CREATE INDEX user_activity_id_index ON public.d_user_activity_log (activity_id);

--d_vendors
CREATE TABLE public.d_vendors(
   ID           serial ,
   vendor_id    BIGINT ,
   name_vendor  text ,
   description  text ,
   PRIMARY KEY (vendor_id)
);
CREATE INDEX vendor_id_index ON public.d_vendors (vendor_id);

- ***** STOPPED HERE************
--d_categories
CREATE TABLE public.d_categories(
   category_id   BIGINT ,
   name_category text ,
   description   text ,
   PRIMARY KEY  (category_id)
);
CREATE INDEX category_id_index ON public.d_categories (category_id);

--d_products
drop table if exists public.d_products cascade;
create table d_products_2 as select * from d_products;

CREATE TABLE public.d_products(
   product_id   BIGINT ,
   category_id  BIGINT ,
   vendor_id    BIGINT,
   name_product text ,
   description  text ,
  dimension_id  BIGINT,
   stock        boolean,
   PRIMARY KEY (product_id),
   FOREIGN KEY (category_id) REFERENCES d_categories(category_id) ON UPDATE cascade,
   FOREIGN KEY (vendor_id) REFERENCES d_vendors(vendor_id) ON UPDATE cascade
);
CREATE INDEX product_id_index ON public.d_products (product_id);

--d_orders
drop table if exists public.d_orders cascade;
CREATE TABLE public.d_orders(
   order_id      BIGINT ,
   payment       NUMERIC(14,2),
   hit_date_time TIMESTAMP,
   PRIMARY KEY (order_id)
);
CREATE INDEX order_id_index ON public.d_orders (order_id);

--d_buckets
CREATE TABLE public.d_buckets(
   bucket_id    BIGINT ,
   order_id     BIGINT ,
   product_id   BIGINT ,
   num          NUMERIC(14,2),
   PRIMARY KEY (bucket_id),
   FOREIGN KEY (product_id) REFERENCES d_products(product_id) ON UPDATE CASCADE,
   FOREIGN KEY (order_id) REFERENCES d_orders(order_id) ON UPDATE CASCADE
);
CREATE INDEX bucket_id ON public.d_buckets (bucket_id);

--sales information
CREATE TABLE public.f_sales(
   sale_id        BIGINT ,
   order_id       BIGINT ,
--   client_id      BIGINT ,
   promotion_id   BIGINT ,
   PRIMARY KEY (sale_id),
   FOREIGN KEY (order_id) REFERENCES d_orders(order_id) ON UPDATE cascade,
   FOREIGN KEY (client_id) REFERENCES d_clients(client_id) ON UPDATE cascade
);
CREATE INDEX sales_order_id_index ON public.f_sales (order_id);
-- новая (целевая) схема с таблицами --

drop table if exists public.d_product_dimensions cascade;

CREATE TABLE public.d_product_dimensions (
	dimension_id int8 NOT NULL,
--	category_id int8 NULL,
--	vendor_id int8 NULL,
--	name_product text NULL,
--	vendor_description text NULL,
--	product_id int8 NULL,
	length numeric(14, 2) NULL,
	width numeric(14, 2) NULL,
	height numeric(14, 2) NULL,
	CONSTRAINT d_product_dimensions_pkey PRIMARY KEY (dimension_id)
);

--- *********************************************** -----
Filling tables with data to meet requirements of the last exersize.

CREATE SEQUENCE category_id_sequence start 1; 
INSERT INTO public.d_categories (category_id , name_category, description) 
 select category_id
      , name_category
      , description from 
  (select nextval('category_id_sequence') as category_id, category[1] as name_category, category[2] as description 
     from ( select (regexp_split_to_array(category , E'\\:+')) as category 
              from orders_attributes oa) as parse_category group by (category[1], category[2]) ) as category_information; 
DROP SEQUENCE category_id_sequence; 

insert into public.d_vendors (vendor_id) select distinct vendor_id from public.d_product_dimensions;

INSERT INTO public.d_products
(product_id, category_id, vendor_id, name_product, description, stock)
select distinct 
		ci.itemcode,
		dc.category_id                                  			as category_id,
        vendorcode                                                  as vendor_id,
        (regexp_split_to_array(ci.description, E'\\:+'))[1]         as name_product,
        concat(
        	(regexp_split_to_array(category, E'\\:+'))[1], ' ',
            (regexp_split_to_array(ci.description, E'\\:+'))[2], ' from ',
            (regexp_split_to_array(ci.description, E'\\:+'))[3]
        ) 															as description,
        ci.stock 													as stock
               from (select *, 
               				(regexp_split_to_array(category, E'\\:+'))[1] as name_category
                        		from orders_attributes oa
                    ) as ci
                        join d_categories dc on ci.name_category = dc.name_category;

select * from public.d_products limit 10;

update public.d_products as t1 set dimension_id = (select dimension_id from public.d_product_dimensions where product_id = t1.product_id);

select count(distinct product_id ) as ss from public.d_product_dimensions limit 10;

-- ***************************

