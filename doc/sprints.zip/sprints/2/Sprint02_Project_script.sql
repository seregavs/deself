DROP TABLE IF EXISTS public.shipping_country_rates CASCADE;
DROP TABLE IF EXISTS public.shipping_agreement CASCADE;
DROP TABLE IF EXISTS public.shipping_transfer CASCADE;
DROP TABLE IF EXISTS public.shipping_info CASCADE;
DROP TABLE IF EXISTS public.shipping_status CASCADE;
DROP VIEW IF EXISTS public.shipping_datamart;

CREATE TABLE public.shipping_country_rates (
	id  SERIAL8 NOT NULL,
	shipping_country text NOT NULL,
	shipping_country_base_rate numeric(14, 3) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE public.shipping_agreement (
	agreement_id BIGINT NOT NULL,
	agreement_number text NOT NULL,
	agreement_rate numeric(14,2) NOT NULL,
	agreement_commission numeric(14,2) NOT NULL,
    PRIMARY KEY (agreement_id)
);

CREATE TABLE public.shipping_transfer (
	id SERIAL8 NOT NULL,
	transfer_type text NOT NULL,
	transfer_model text NOT NULL,
	shipping_transfer_rate numeric(14, 3) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE public.shipping_info (
	shipping_id BIGINT NOT NULL,
	vendor_id BIGINT NOT NULL,
	payment_amount numeric(14, 2) NOT NULL,
	shipping_plan_datetime timestamp NOT NULL,
	shipping_transfer_id BIGINT NULL,
	shipping_agreement_id BIGINT NULL,
	shipping_country_rate_id BIGINT NULL,
   PRIMARY KEY  (shipping_id),
   FOREIGN KEY  (shipping_transfer_id) REFERENCES shipping_transfer(id) ON UPDATE CASCADE,
   FOREIGN KEY  (shipping_agreement_id) REFERENCES shipping_agreement(agreement_id) ON UPDATE CASCADE,
   FOREIGN KEY  (shipping_country_rate_id) REFERENCES shipping_country_rates(id) ON UPDATE CASCADE
);

CREATE TABLE public.shipping_status (
	shipping_id bigint NOT NULL,
	status text NOT NULL,
	state text NOT NULL,
	shipping_start_fact_datetime timestamp NULL,
	shipping_end_fact_datetime timestamp NULL,
    PRIMARY KEY (shipping_id),
    FOREIGN KEY  (shipping_id) REFERENCES public.shipping_info(shipping_id) ON UPDATE CASCADE
);

insert into public.shipping_country_rates(shipping_country, shipping_country_base_rate)
 select distinct shipping_country, shipping_country_base_rate from public.shipping order by 1 asc;

insert into public.shipping_agreement (
select 
      distinct  (regexp_split_to_array(vendor_agreement_description, E':+'))[1]::BIGINT as agreement_id
     , (regexp_split_to_array(vendor_agreement_description, E':+'))[2] as agreement_number	
     , cast((regexp_split_to_array(vendor_agreement_description, E':+'))[3] as decimal(14,2)) as agreement_rate
     , cast((regexp_split_to_array(vendor_agreement_description, E':+'))[4] as decimal(14,2)) as agreement_commission	 
  from public.shipping);

insert into public.shipping_transfer (transfer_type, transfer_model, shipping_transfer_rate )
 select
       (regexp_split_to_array(shipping_transfer_description, E':+'))[1] as transfer_type
     , (regexp_split_to_array(shipping_transfer_description, E':+'))[2] as transfer_model
     , shipping_transfer_rate 
  from (select distinct shipping_transfer_description, shipping_transfer_rate
          from public.shipping ) as v1
 order by transfer_type;

insert into public.shipping_info (shipping_id, vendor_id, payment_amount
                         , shipping_plan_datetime, shipping_transfer_id
                         , shipping_agreement_id, shipping_country_rate_id )
( select distinct 
       shippingid as shipping_id
     , vendorid as vendor_id
	 , payment_amount
	 , shipping_plan_datetime
	 , t1.id as shipping_transfer_id
	 , (regexp_split_to_array(t0.vendor_agreement_description, E':+'))[1]::BIGINT as shipping_agreement_id
	 , t3.id as shipping_country_rate_id
  from public.shipping as t0, public.shipping_transfer as t1, public.shipping_country_rates as t3
 where (regexp_split_to_array(t0.shipping_transfer_description, E':+'))[1] = t1.transfer_type
   and (regexp_split_to_array(t0.shipping_transfer_description, E':+'))[2] = t1.transfer_model
   and t0.shipping_country = t3.shipping_country );

/*
  Создайте таблицу статусов о доставке shipping_status и включите туда информацию из 
  лога shipping (status , state). Добавьте туда вычислимую информацию по фактическому времени 
  доставки shipping_start_fact_datetime, shipping_end_fact_datetime . 
  Отразите для каждого уникального shipping_id его итоговое состояние доставки
  
  state — промежуточные точки заказа, которые изменяются в соответствии с обновлением информации о доставке по времени state_datetime.
booked (пер. «заказано»);
fulfillment — заказ доставлен на склад отправки;
queued (пер. «в очереди») — заказ в очереди на запуск доставки;
transition (пер. «передача») — запущена доставка заказа;
pending (пер. «в ожидании») — заказ доставлен в пункт выдачи и ожидает получения;
recieved (пер. «получено») — покупатель забрал заказ;
returned (пер. «возвращено») — покупатель возвратил заказ после того, как его забрал.
  
  */
  
 insert into public.shipping_status (
  with t0 as (select shipping_id, status, state from (
	select shippingid as shipping_id
		, status, state
		, rank() OVER (PARTITION BY shippingid ORDER BY id DESC) as rn
	  from public.shipping 
	) c1 WHERE rn = 1),
       t1 as (select shippingid as shipping_id, state_datetime as shipping_start_fact_datetime
    from public.shipping
   where state = 'booked'),
       t2 as   (select shippingid as shipping_id, state_datetime as shipping_end_fact_datetime
    from public.shipping
   where state = 'recieved')
  select t0.*, t1.shipping_start_fact_datetime, t2.shipping_end_fact_datetime
    from t0 left outer join t1 on t0.shipping_id = t1.shipping_id
            left outer join t2 on t0.shipping_id = t2.shipping_id
  order by 1 asc);


CREATE  VIEW public.shipping_datamart AS
  SELECT t0.shipping_id, t0.vendor_id, t1.transfer_type
      ,EXTRACT(DAY FROM t2.shipping_end_fact_datetime - t2.shipping_start_fact_datetime )::INTEGER AS full_day_at_shipping
      ,case when t2.shipping_end_fact_datetime > shipping_plan_datetime then 1 else 0 end as is_delay
      ,case when t2.status = 'finished' then 1 else 0 end as is_shipping_finish
      ,case when t2.shipping_end_fact_datetime > shipping_plan_datetime then EXTRACT(DAY FROM t2.shipping_end_fact_datetime - shipping_plan_datetime) else 0 end as delay_day_at_shipping
      --,payment_amount
      ,payment_amount * (t3.shipping_country_base_rate + t4.agreement_rate + t1.shipping_transfer_rate) as vat
      ,payment_amount * agreement_commission as profit
    FROM public.shipping_info as t0, public.shipping_transfer t1, public.shipping_status t2, public.shipping_country_rates t3, public.shipping_agreement t4
   WHERE t0.shipping_transfer_id = t1.id
     AND t0.shipping_id = t2.shipping_id
	 AND t0.shipping_country_rate_id = t3.id
	 AND t0.shipping_agreement_id = t4.agreement_id







